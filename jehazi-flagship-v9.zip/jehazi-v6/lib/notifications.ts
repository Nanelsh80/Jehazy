import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

if (Platform.OS !== "web") {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldPlaySound: false,
      shouldSetBadge: true,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });
}

export async function enableNotifications() {
  if (Platform.OS === "web") return false;
  const existing = await Notifications.getPermissionsAsync();
  let status = existing.status;
  if (status !== "granted") {
    const requested = await Notifications.requestPermissionsAsync();
    status = requested.status;
  }
  if (status !== "granted") return false;
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("jehazi", {
      name: "JEHAZI",
      importance: Notifications.AndroidImportance.DEFAULT,
      vibrationPattern: [0, 200, 100, 200],
      sound: undefined,
    });
  }
  return true;
}

function dateAtNoon(date: Date) {
  const next = new Date(date);
  next.setHours(12, 0, 0, 0);
  return next;
}

export function reminderDate(isoDate: string, daysBefore: number, now = new Date()) {
  const target = new Date(`${isoDate}T12:00:00`);
  if (Number.isNaN(target.getTime())) return null;
  target.setDate(target.getDate() - daysBefore);
  const date = dateAtNoon(target);
  return date.getTime() > now.getTime() ? date : null;
}

export async function scheduleWeddingReminders(weddingDate: string) {
  if (!(await enableNotifications())) return 0;
  await Notifications.cancelAllScheduledNotificationsAsync();
  let count = 0;
  for (const days of [30, 14, 7, 1]) {
    const date = reminderDate(weddingDate, days);
    if (!date) continue;
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "JEHAZI • جهازي",
        body: days === 1 ? "باقي يوم واحد على فرحك 🤍 خدي نفسًا وراجعي آخر قائمة تجهيز." : `باقي ${days} يوم على فرحك ✨ راجعي أولويات التجهيز هذا الأسبوع.`,
        data: { type: "wedding", days },
      },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date, channelId: "jehazi" },
    });
    count += 1;
  }
  return count;
}

export async function scheduleWarrantyReminder(itemName: string, warrantyEndDate: string) {
  if (!(await enableNotifications())) return false;
  const date = reminderDate(warrantyEndDate, 30);
  if (!date) return false;
  await Notifications.scheduleNotificationAsync({
    content: {
      title: "ضمان قريب من الانتهاء 🛡️",
      body: `ضمان ${itemName} هينتهي خلال حوالي 30 يوم. راجعي الفاتورة والضمان في جهازي.`,
      data: { type: "warranty", itemName, warrantyEndDate },
    },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date, channelId: "jehazi" },
  });
  return true;
}

export async function cancelScheduledNotifications() {
  if (Platform.OS === "web") return;
  await Notifications.cancelAllScheduledNotificationsAsync();
}
