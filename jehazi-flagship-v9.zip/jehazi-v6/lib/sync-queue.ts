import AsyncStorage from "@react-native-async-storage/async-storage";
import type { BrideProfile, InventoryItem } from "@/lib/inventory-context";

export type SyncSnapshot = { profile: BrideProfile; items: InventoryItem[] };
export type SyncQueueState = {
  snapshot: SyncSnapshot;
  queuedAt: string;
  attempts: number;
  lastError?: string;
};

const KEY = "jehazi.sync.queue.v1";

export async function readSyncQueue(): Promise<SyncQueueState | null> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as SyncQueueState) : null;
  } catch {
    return null;
  }
}

export async function queueSnapshot(snapshot: SyncSnapshot, error?: unknown) {
  const previous = await readSyncQueue();
  const next: SyncQueueState = {
    snapshot,
    queuedAt: previous?.queuedAt ?? new Date().toISOString(),
    attempts: previous?.attempts ?? 0,
    lastError: error instanceof Error ? error.message : previous?.lastError,
  };
  await AsyncStorage.setItem(KEY, JSON.stringify(next));
  return next;
}

export async function markSyncAttempt(error?: unknown) {
  const current = await readSyncQueue();
  if (!current) return null;
  const next = {
    ...current,
    attempts: current.attempts + 1,
    lastError: error instanceof Error ? error.message : current.lastError,
  };
  await AsyncStorage.setItem(KEY, JSON.stringify(next));
  return next;
}

export async function clearSyncQueue() {
  await AsyncStorage.removeItem(KEY);
}

export async function hasPendingSync() {
  return Boolean(await readSyncQueue());
}
