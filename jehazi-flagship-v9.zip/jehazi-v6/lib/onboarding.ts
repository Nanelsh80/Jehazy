export const ONBOARDING_STEPS = ["welcome", "profile", "setup"] as const;

export type OnboardingStep = (typeof ONBOARDING_STEPS)[number];

export function onboardingStepFromParam(value: string | string[] | undefined): OnboardingStep {
  const step = Array.isArray(value) ? value[0] : value;
  return step === "welcome" || step === "setup" ? step : "profile";
}

export function shouldUseStarterList(value: boolean | null | undefined) {
  return value === true;
}
