import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from "react";
import { AppState } from "react-native";
import * as Api from "@/lib/_core/api";
import { clearSyncQueue, hasPendingSync, markSyncAttempt, queueSnapshot, readSyncQueue } from "@/lib/sync-queue";

export type CategoryKey = "device" | "clothes" | "bedding" | "small";
export type ItemStatus = "undecided" | "missing" | "toBuy" | "reserved" | "deposit" | "purchased" | "shipping" | "received" | "notNeeded";
export type Priority = "high" | "medium" | "low";

export interface CatalogItem {
  id: string;
  name: string;
  category: CategoryKey;
  subcategory: string;
  suggestedQty: number;
  unit: "قطعة" | "طقم" | "زوج";
  required: boolean;
  defaultUnitPrice: number;
}

export interface InventoryItem {
  id: string;
  catalogId?: string;
  name: string;
  category: CategoryKey;
  subcategory: string;
  room: string;
  requiredQty: number;
  ownedQty: number;
  status: ItemStatus;
  unitPrice: number;
  amountPaid: number;
  priority: Priority;
  store: string;
  brand: string;
  size: string;
  color: string;
  notes: string;
  purchaseDate?: string;
  deliveryDate?: string;
  photoUri?: string;
  receiptUri?: string;
  receiptName?: string;
  warrantyUri?: string;
  warrantyName?: string;
  warrantyStartDate?: string;
  warrantyEndDate?: string;
  warrantyProvider?: string;
  warrantyNotes?: string;
  photoAssetId?: string;
  receiptAssetId?: string;
  warrantyAssetId?: string;
}

export interface BrideProfile {
  name: string;
  weddingDate: string;
  budget: number;
}

interface InventoryContextValue {
  items: InventoryItem[];
  profile: BrideProfile;
  hydrated: boolean;
  onboardingComplete: boolean;
  addItem: (item: Omit<InventoryItem, "id">) => void;
  updateItem: (id: string, patch: Partial<InventoryItem>) => void;
  deleteItem: (id: string) => void;
  updateProfile: (patch: Partial<BrideProfile>) => void;
  completeOnboarding: (profile: BrideProfile, useStarterList: boolean) => void;
  resetDemo: () => void;
  pendingSync: boolean;
  lastSyncedAt: string | null;
  retrySync: () => Promise<void>;
}

const STORAGE_KEY = "jehazi.inventory.v2";
const PROFILE_KEY = "jehazi.profile.v2";
const ONBOARDING_KEY = "jehazi.onboarding.v2";
const LEGACY_KEYS = ["jehazi.inventory.v1", "jehazi.profile.v1", "jehazi.onboarding.v1"];

export const CATEGORY_META: Record<CategoryKey, { label: string; short: string; icon: string; tint: string; soft: string }> = {
  device: { label: "الجهاز", short: "الجهاز", icon: "kitchen", tint: "#A96C56", soft: "#F1DED5" },
  clothes: { label: "اللبس", short: "اللبس", icon: "checkroom", tint: "#B68A42", soft: "#F3E7C9" },
  bedding: { label: "المفروشات", short: "مفروشات", icon: "bed", tint: "#718B74", soft: "#DDE8DA" },
  small: { label: "الرفايع", short: "الرفايع", icon: "grid-view", tint: "#8A718A", soft: "#E9DFEA" },
};

export const STATUS_META: Record<ItemStatus, { label: string; color: string; soft: string }> = {
  undecided: { label: "لم أقرر", color: "#8C8B86", soft: "#EEECE7" },
  missing: { label: "ناقص", color: "#BC5C58", soft: "#F9E0DD" },
  toBuy: { label: "مطلوب شراؤه", color: "#B77B34", soft: "#F6E6C9" },
  reserved: { label: "تم الحجز", color: "#8C6A95", soft: "#EDE3F0" },
  deposit: { label: "تم دفع عربون", color: "#84704B", soft: "#EEE8D8" },
  purchased: { label: "تم الشراء", color: "#527E67", soft: "#DCECE2" },
  shipping: { label: "في الطريق", color: "#5C7F9C", soft: "#DDEAF5" },
  received: { label: "تم الاستلام", color: "#3F7D5C", soft: "#D9EBDD" },
  notNeeded: { label: "لا أحتاجه", color: "#8B8B8B", soft: "#ECECEC" },
};

export const starterCatalog: CatalogItem[] = [
  { id: "device-1", name: "ثلاجة 16 قدم", category: "device", subcategory: "الأجهزة الكهربائية", suggestedQty: 1, unit: "قطعة", required: true, defaultUnitPrice: 28500 },
  { id: "device-2", name: "غسالة ملابس", category: "device", subcategory: "الأجهزة الكهربائية", suggestedQty: 1, unit: "قطعة", required: true, defaultUnitPrice: 18500 },
  { id: "device-3", name: "طقم حلل جرانيت", category: "device", subcategory: "أدوات المطبخ", suggestedQty: 1, unit: "طقم", required: true, defaultUnitPrice: 3800 },
  { id: "device-4", name: "طقم أطباق يومي", category: "device", subcategory: "أدوات السفرة", suggestedQty: 1, unit: "طقم", required: true, defaultUnitPrice: 2400 },
  { id: "clothes-1", name: "بيجامات", category: "clothes", subcategory: "ملابس المنزل", suggestedQty: 6, unit: "قطعة", required: true, defaultUnitPrice: 650 },
  { id: "clothes-2", name: "روب استقبال", category: "clothes", subcategory: "ملابس النوم", suggestedQty: 2, unit: "قطعة", required: true, defaultUnitPrice: 900 },
  { id: "clothes-3", name: "كوتشي أبيض", category: "clothes", subcategory: "الأحذية", suggestedQty: 1, unit: "زوج", required: false, defaultUnitPrice: 1800 },
  { id: "bedding-1", name: "ملايات استك", category: "bedding", subcategory: "الملايات", suggestedQty: 6, unit: "طقم", required: true, defaultUnitPrice: 750 },
  { id: "bedding-2", name: "فوط حمام كبيرة", category: "bedding", subcategory: "الحمام", suggestedQty: 8, unit: "قطعة", required: true, defaultUnitPrice: 350 },
  { id: "bedding-3", name: "لحاف شتوي", category: "bedding", subcategory: "أغطية السرير", suggestedQty: 1, unit: "قطعة", required: false, defaultUnitPrice: 3200 },
  { id: "small-1", name: "شماعات خشب", category: "small", subcategory: "رفايا غرفة النوم", suggestedQty: 20, unit: "قطعة", required: true, defaultUnitPrice: 45 },
  { id: "small-2", name: "منظم توابل", category: "small", subcategory: "رفايا المطبخ", suggestedQty: 2, unit: "قطعة", required: false, defaultUnitPrice: 650 },
  { id: "small-3", name: "سلة غسيل", category: "small", subcategory: "رفايا الحمام", suggestedQty: 1, unit: "قطعة", required: false, defaultUnitPrice: 850 },
];

const extendedCatalog: CatalogItem[] = [
  { id: "device-5", name: "تكييف غرفة النوم", category: "device", subcategory: "الأجهزة الكهربائية", suggestedQty: 1, unit: "قطعة", required: false, defaultUnitPrice: 26000 },
  { id: "device-6", name: "ميكروويف", category: "device", subcategory: "أدوات المطبخ", suggestedQty: 1, unit: "قطعة", required: false, defaultUnitPrice: 6500 },
  { id: "device-7", name: "خلاط", category: "device", subcategory: "أدوات المطبخ", suggestedQty: 1, unit: "قطعة", required: true, defaultUnitPrice: 1800 },
  { id: "device-8", name: "كبة", category: "device", subcategory: "أدوات المطبخ", suggestedQty: 1, unit: "قطعة", required: false, defaultUnitPrice: 1500 },
  { id: "device-9", name: "مكنسة كهربائية", category: "device", subcategory: "أجهزة المنزل", suggestedQty: 1, unit: "قطعة", required: true, defaultUnitPrice: 7500 },
  { id: "device-10", name: "سخان مياه", category: "device", subcategory: "أجهزة المنزل", suggestedQty: 1, unit: "قطعة", required: true, defaultUnitPrice: 9000 },
  { id: "clothes-4", name: "لانجري أطقم", category: "clothes", subcategory: "الملابس الداخلية", suggestedQty: 8, unit: "قطعة", required: true, defaultUnitPrice: 550 },
  { id: "clothes-5", name: "ملابس خروج", category: "clothes", subcategory: "ملابس الخروج", suggestedQty: 5, unit: "قطعة", required: true, defaultUnitPrice: 1800 },
  { id: "clothes-6", name: "شبشب منزلي", category: "clothes", subcategory: "الأحذية", suggestedQty: 2, unit: "زوج", required: true, defaultUnitPrice: 450 },
  { id: "clothes-7", name: "شنط خروج", category: "clothes", subcategory: "الإكسسوارات", suggestedQty: 3, unit: "قطعة", required: false, defaultUnitPrice: 1200 },
  { id: "bedding-4", name: "مفارش سرير", category: "bedding", subcategory: "المفروشات", suggestedQty: 4, unit: "طقم", required: true, defaultUnitPrice: 1250 },
  { id: "bedding-5", name: "بطاطين", category: "bedding", subcategory: "أغطية السرير", suggestedQty: 2, unit: "قطعة", required: true, defaultUnitPrice: 1800 },
  { id: "bedding-6", name: "مخدات نوم", category: "bedding", subcategory: "المفروشات", suggestedQty: 4, unit: "قطعة", required: true, defaultUnitPrice: 450 },
  { id: "bedding-7", name: "ستائر", category: "bedding", subcategory: "الستائر", suggestedQty: 5, unit: "قطعة", required: false, defaultUnitPrice: 1200 },
  { id: "small-4", name: "طقم أدوات مطبخ", category: "small", subcategory: "رفايا المطبخ", suggestedQty: 1, unit: "طقم", required: true, defaultUnitPrice: 2200 },
  { id: "small-5", name: "طقم سكاكين", category: "small", subcategory: "رفايا المطبخ", suggestedQty: 1, unit: "طقم", required: true, defaultUnitPrice: 950 },
  { id: "small-6", name: "علب تخزين", category: "small", subcategory: "رفايا المطبخ", suggestedQty: 8, unit: "قطعة", required: true, defaultUnitPrice: 180 },
  { id: "small-7", name: "طقم حمام", category: "small", subcategory: "رفايا الحمام", suggestedQty: 1, unit: "طقم", required: true, defaultUnitPrice: 1200 },
  { id: "small-8", name: "مستلزمات تنظيف", category: "small", subcategory: "التنظيف", suggestedQty: 1, unit: "طقم", required: true, defaultUnitPrice: 1400 },
  { id: "small-9", name: "منظمات أدراج", category: "small", subcategory: "التنظيم", suggestedQty: 6, unit: "قطعة", required: false, defaultUnitPrice: 180 },
];

starterCatalog.push(...extendedCatalog);

export function catalogToInventoryItem(catalog: CatalogItem, overrides: Partial<InventoryItem> = {}): InventoryItem {
  return {
    id: catalog.id,
    catalogId: catalog.id,
    name: catalog.name,
    category: catalog.category,
    subcategory: catalog.subcategory,
    room: "المنزل",
    requiredQty: catalog.suggestedQty,
    ownedQty: 0,
    status: "toBuy",
    unitPrice: catalog.defaultUnitPrice,
    amountPaid: 0,
    priority: catalog.required ? "high" : "medium",
    store: "",
    brand: "",
    size: "",
    color: "",
    notes: "",
    ...overrides,
  };
}

const seedItems: InventoryItem[] = [
  { id: "device-1", catalogId: "device-1", name: "ثلاجة 16 قدم", category: "device", subcategory: "الأجهزة الكهربائية", room: "المطبخ", requiredQty: 1, ownedQty: 1, status: "received", unitPrice: 28500, amountPaid: 28500, priority: "high", store: "بي تك", brand: "شارب", size: "16 قدم", color: "فضي", notes: "الضمان محفوظ" },
  { id: "device-2", catalogId: "device-2", name: "غسالة ملابس", category: "device", subcategory: "الأجهزة الكهربائية", room: "المطبخ", requiredQty: 1, ownedQty: 1, status: "purchased", unitPrice: 18500, amountPaid: 9000, priority: "high", store: "العربي جروب", brand: "فريش", size: "9 كيلو", color: "أبيض", notes: "التوصيل يوم الخميس" },
  { id: "device-3", catalogId: "device-3", name: "طقم حلل جرانيت", category: "device", subcategory: "أدوات المطبخ", room: "المطبخ", requiredQty: 1, ownedQty: 0, status: "toBuy", unitPrice: 3800, amountPaid: 0, priority: "high", store: "كارفور", brand: "رويال", size: "12 قطعة", color: "رمادي", notes: "اختيار النوع المضاد للخدش" },
  { id: "device-4", catalogId: "device-4", name: "طقم أطباق يومي", category: "device", subcategory: "أدوات السفرة", room: "السفرة", requiredQty: 1, ownedQty: 1, status: "received", unitPrice: 2400, amountPaid: 2400, priority: "medium", store: "هوم سنتر", brand: "", size: "24 قطعة", color: "أوف وايت", notes: "" },
  { id: "clothes-1", catalogId: "clothes-1", name: "بيجامات", category: "clothes", subcategory: "ملابس المنزل", room: "غرفة النوم", requiredQty: 6, ownedQty: 3, status: "missing", unitPrice: 650, amountPaid: 1950, priority: "high", store: "محل روز", brand: "", size: "M", color: "متنوع", notes: "مقاسات مريحة" },
  { id: "clothes-2", catalogId: "clothes-2", name: "روب استقبال", category: "clothes", subcategory: "ملابس النوم", room: "غرفة النوم", requiredQty: 2, ownedQty: 1, status: "purchased", unitPrice: 900, amountPaid: 900, priority: "medium", store: "", brand: "", size: "M", color: "وردي ترابي", notes: "" },
  { id: "clothes-3", catalogId: "clothes-3", name: "كوتشي أبيض", category: "clothes", subcategory: "الأحذية", room: "غرفة النوم", requiredQty: 1, ownedQty: 0, status: "toBuy", unitPrice: 1800, amountPaid: 0, priority: "low", store: "", brand: "", size: "39", color: "أبيض", notes: "" },
  { id: "bedding-1", catalogId: "bedding-1", name: "ملايات استك", category: "bedding", subcategory: "الملايات", room: "غرفة النوم", requiredQty: 6, ownedQty: 4, status: "missing", unitPrice: 750, amountPaid: 3000, priority: "high", store: "مفروشات العروسة", brand: "", size: "180 سم", color: "أوف وايت", notes: "ناقص طقمين" },
  { id: "bedding-2", catalogId: "bedding-2", name: "فوط حمام كبيرة", category: "bedding", subcategory: "الحمام", room: "الحمام", requiredQty: 8, ownedQty: 4, status: "toBuy", unitPrice: 350, amountPaid: 1400, priority: "medium", store: "تاكي", brand: "", size: "كبير", color: "بيج", notes: "" },
  { id: "bedding-3", catalogId: "bedding-3", name: "لحاف شتوي", category: "bedding", subcategory: "أغطية السرير", room: "غرفة النوم", requiredQty: 1, ownedQty: 1, status: "received", unitPrice: 3200, amountPaid: 3200, priority: "low", store: "مفروشات النجار", brand: "", size: "King", color: "رمادي فاتح", notes: "" },
  { id: "small-1", catalogId: "small-1", name: "شماعات خشب", category: "small", subcategory: "رفايا غرفة النوم", room: "غرفة النوم", requiredQty: 20, ownedQty: 12, status: "toBuy", unitPrice: 45, amountPaid: 540, priority: "medium", store: "دايسو", brand: "", size: "", color: "خشبي", notes: "" },
  { id: "small-2", catalogId: "small-2", name: "منظم توابل", category: "small", subcategory: "رفايا المطبخ", room: "المطبخ", requiredQty: 2, ownedQty: 0, status: "missing", unitPrice: 650, amountPaid: 0, priority: "medium", store: "", brand: "", size: "", color: "شفاف", notes: "" },
  { id: "small-3", catalogId: "small-3", name: "سلة غسيل", category: "small", subcategory: "رفايا الحمام", room: "الحمام", requiredQty: 1, ownedQty: 1, status: "received", unitPrice: 850, amountPaid: 850, priority: "low", store: "", brand: "", size: "كبير", color: "بيج", notes: "" },
];

const initialProfile: BrideProfile = { name: "", weddingDate: "", budget: 0 };

export function remainingQty(item: InventoryItem) {
  return Math.max(item.requiredQty - item.ownedQty, 0);
}

export function shoppingListItems(items: InventoryItem[]) {
  return items.filter((item) => remainingQty(item) > 0 && item.status !== "notNeeded");
}

export function itemTotal(item: InventoryItem) {
  return item.requiredQty * item.unitPrice;
}

export function overallProgress(items: InventoryItem[]) {
  const active = items.filter((item) => item.status !== "notNeeded");
  const required = active.reduce((sum, item) => sum + item.requiredQty, 0);
  const owned = active.reduce((sum, item) => sum + Math.min(item.ownedQty, item.requiredQty), 0);
  return required ? Math.round((owned / required) * 100) : 0;
}

export function categoryProgress(items: InventoryItem[], category: CategoryKey) {
  const active = items.filter((item) => item.category === category && item.status !== "notNeeded");
  const required = active.reduce((sum, item) => sum + item.requiredQty, 0);
  const owned = active.reduce((sum, item) => sum + Math.min(item.ownedQty, item.requiredQty), 0);
  return required ? Math.round((owned / required) * 100) : 0;
}

export function subcategoryProgress(items: InventoryItem[], category: CategoryKey, subcategory: string) {
  const active = items.filter((item) => item.category === category && item.subcategory === subcategory && item.status !== "notNeeded");
  const required = active.reduce((sum, item) => sum + item.requiredQty, 0);
  const owned = active.reduce((sum, item) => sum + Math.min(item.ownedQty, item.requiredQty), 0);
  return required ? Math.round((owned / required) * 100) : 0;
}

export function budgetTotals(items: InventoryItem[]) {
  const active = items.filter((item) => item.status !== "notNeeded");
  const estimated = active.reduce((sum, item) => sum + itemTotal(item), 0);
  const paid = active.reduce((sum, item) => sum + item.amountPaid, 0);
  return { estimated, paid, remaining: Math.max(estimated - paid, 0) };
}

export function categoryBudget(items: InventoryItem[], category: CategoryKey) {
  return budgetTotals(items.filter((item) => item.category === category));
}

export function daysUntilWedding(date: string) {
  const wedding = new Date(`${date}T12:00:00`).getTime();
  return Math.max(Math.ceil((wedding - Date.now()) / 86400000), 0);
}

export function isValidWeddingDate(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  const date = new Date(`${value}T12:00:00`);
  return date.getFullYear() === year && date.getMonth() + 1 === month && date.getDate() === day;
}

export function formatMoney(value: number) {
  return `${Math.round(value).toLocaleString("ar-EG")} ج.م`;
}

export function daysUntilDate(date?: string) {
  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
  const target = new Date(`${date}T12:00:00`).getTime();
  if (!Number.isFinite(target)) return null;
  return Math.ceil((target - Date.now()) / 86400000);
}

export function warrantyState(item: InventoryItem) {
  const days = daysUntilDate(item.warrantyEndDate);
  if (days === null) return { state: "missing" as const, days: null };
  if (days < 0) return { state: "expired" as const, days };
  if (days <= 30) return { state: "soon" as const, days };
  return { state: "active" as const, days };
}

export function warrantyItems(items: InventoryItem[]) {
  return items.filter((item) => Boolean(item.warrantyEndDate || item.warrantyUri)).sort((a, b) => {
    const ad = daysUntilDate(a.warrantyEndDate) ?? 999999;
    const bd = daysUntilDate(b.warrantyEndDate) ?? 999999;
    return ad - bd;
  });
}

export function smartShoppingList(items: InventoryItem[], profile: BrideProfile) {
  const days = daysUntilWedding(profile.weddingDate);
  return shoppingListItems(items).map((item) => {
    const cost = remainingQty(item) * item.unitPrice;
    const urgency = item.priority === "high" ? 3 : item.priority === "medium" ? 2 : 1;
    const statusBoost = item.status === "missing" ? 2 : item.status === "toBuy" ? 1 : 0;
    const deadlineBoost = days <= 30 ? 2 : days <= 60 ? 1 : 0;
    const score = urgency * 3 + statusBoost + deadlineBoost;
    return { item, cost, score };
  }).sort((a, b) => b.score - a.score || a.cost - b.cost);
}

export interface SmartBudgetPlan {
  remainingBudget: number;
  remainingEstimate: number;
  weeks: number;
  weeklyCap: number;
  committed: number;
  recommendedNow: InventoryItem[];
  risk: "safe" | "watch" | "over";
}

export function smartBudgetPlan(items: InventoryItem[], profile: BrideProfile): SmartBudgetPlan {
  const totals = budgetTotals(items);
  const remainingBudget = Math.max(profile.budget - totals.paid, 0);
  const remainingEstimate = Math.max(totals.estimated - totals.paid, 0);
  const weeks = Math.max(Math.ceil(daysUntilWedding(profile.weddingDate) / 7), 1);
  const pending = shoppingListItems(items).slice().sort((a, b) => {
    const priority = (x: InventoryItem) => x.priority === "high" ? 3 : x.priority === "medium" ? 2 : 1;
    const delivery = (x: InventoryItem) => x.status === "toBuy" || x.status === "missing" ? 1 : 0;
    return priority(b) - priority(a) || delivery(b) - delivery(a) || itemTotal(b) - itemTotal(a);
  });
  const recommendedNow: InventoryItem[] = [];
  let committed = 0;
  for (const item of pending) {
    const cost = remainingQty(item) * item.unitPrice;
    if (item.priority === "high" && committed + cost <= Math.max(remainingBudget, 1)) {
      recommendedNow.push(item); committed += cost;
    }
    if (recommendedNow.length >= 3) break;
  }
  const weeklyCap = remainingBudget / weeks;
  const risk = remainingEstimate > remainingBudget * 1.05 ? "over" : remainingEstimate > remainingBudget * 0.9 ? "watch" : "safe";
  return { remainingBudget, remainingEstimate, weeks, weeklyCap, committed, recommendedNow, risk };
}

export interface WeeklyPlan {
  title: string;
  detail: string;
  icon: string;
}

export function weeklyPreparationPlan(items: InventoryItem[], profile: BrideProfile): WeeklyPlan[] {
  const days = daysUntilWedding(profile.weddingDate);
  const pending = shoppingListItems(items);
  const high = pending.filter((item) => item.priority === "high").slice(0, 2);
  const shipping = pending.filter((item) => item.status === "shipping" || item.status === "reserved").slice(0, 2);
  const plan: WeeklyPlan[] = [];
  if (high.length) plan.push({ title: "أولويتك هذا الأسبوع", detail: high.map((item) => item.name).join("، "), icon: "priority-high" });
  if (shipping.length) plan.push({ title: "متابعة الطلبات", detail: shipping.map((item) => item.name).join("، "), icon: "local-shipping" });
  if (profile.budget > 0) {
    const remaining = Math.max(profile.budget - budgetTotals(items).paid, 0);
    const weeks = Math.max(Math.ceil(days / 7), 1);
    plan.push({ title: "سقف الإنفاق الأسبوعي", detail: `${formatMoney(remaining / weeks)} تقريبًا حتى موعد الفرح`, icon: "account-balance-wallet" });
  }
  if (!plan.length) plan.push({ title: "الأسبوع ده", detail: "راجعي القوائم، حدّثي الكميات، واختاري قطعة واحدة على الأقل لإغلاقها بالكامل.", icon: "auto-awesome" });
  return plan.slice(0, 3);
}

export interface PreparationInsight {
  id: string;
  title: string;
  detail: string;
  priority: Priority;
  icon: string;
}

export function preparationInsights(items: InventoryItem[], profile: BrideProfile): PreparationInsight[] {
  const days = daysUntilWedding(profile.weddingDate);
  const pending = items.filter((item) => item.status !== "notNeeded" && remainingQty(item) > 0);
  const high = pending.filter((item) => item.priority === "high");
  const shipping = pending.filter((item) => item.status === "shipping" || item.status === "reserved");
  const total = budgetTotals(items);
  const insights: PreparationInsight[] = [];
  if (days <= 60 && high.length) insights.push({ id: "deadline", title: "الوقت بيقرب", detail: `قدامك ${days} يوم وفي ${high.length} حاجة عالية الأولوية ناقصة. ابدئي بيهم الأول.`, priority: "high", icon: "schedule" });
  if (shipping.length) insights.push({ id: "followup", title: "تابعي الطلبات", detail: `عندك ${shipping.length} ${shipping.length === 1 ? "قطعة" : "قطع"} محجوزة أو في الطريق وتحتاج متابعة.`, priority: "medium", icon: "local-shipping" });
  if (profile.budget > 0 && total.estimated > profile.budget) insights.push({ id: "budget", title: "الميزانية محتاجة مراجعة", detail: `التكلفة المتوقعة أعلى من ميزانيتك بحوالي ${formatMoney(total.estimated - profile.budget)}.`, priority: "high", icon: "warning" });
  if (!insights.length) insights.push({ id: "good", title: "أنتِ ماشية كويس ✨", detail: "مفيش تنبيه عاجل دلوقتي. كمّلي خطوة بخطوة وراجعي القطع الناقصة أسبوعيًا.", priority: "low", icon: "check-circle" });
  return insights.slice(0, 3);
}

export function InventoryProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [profile, setProfile] = useState<BrideProfile>(initialProfile);
  const [hydrated, setHydrated] = useState(false);
  const [onboardingComplete, setOnboardingComplete] = useState(false);
  const [pendingSync, setPendingSync] = useState(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(null);

  const cloudReady = useRef(false);
  const syncTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const syncSnapshot = async (snapshot: { profile: BrideProfile; items: InventoryItem[] }) => {
    try {
      const user = await Api.getMe();
      if (!user) return false;
      await Api.saveJeHaziSnapshot(snapshot);
      await clearSyncQueue();
      setPendingSync(false);
      setLastSyncedAt(new Date().toISOString());
      return true;
    } catch (error) {
      await markSyncAttempt(error);
      await queueSnapshot(snapshot, error);
      setPendingSync(true);
      return false;
    }
  };

  const retrySync = async () => {
    const queued = await readSyncQueue();
    if (!queued) {
      setPendingSync(false);
      return;
    }
    await syncSnapshot(queued.snapshot);
  };

  useEffect(() => {
    let cancelled = false;
    async function hydrate() {
      await AsyncStorage.multiRemove(LEGACY_KEYS).catch(() => undefined);
      const [storedItems, storedProfile, storedOnboarding, queued] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEY),
        AsyncStorage.getItem(PROFILE_KEY),
        AsyncStorage.getItem(ONBOARDING_KEY),
        readSyncQueue(),
      ]);

      let localItems: InventoryItem[] = [];
      let localProfile = initialProfile;
      let localOnboarding = false;
      try { if (storedItems) localItems = JSON.parse(storedItems); } catch { /* ignore corrupt local data */ }
      try { if (storedProfile) localProfile = { ...initialProfile, ...JSON.parse(storedProfile) }; } catch { /* ignore corrupt local data */ }
      localOnboarding = storedOnboarding === "true";

      if (cancelled) return;
      setItems(localItems);
      setProfile(localProfile);
      setOnboardingComplete(localOnboarding);
      setPendingSync(Boolean(queued));
      setHydrated(true);

      try {
        const user = await Api.getMe();
        if (!user || cancelled) { cloudReady.current = true; return; }
        if (queued) {
          await retrySync();
        } else {
          const cloud = await Api.getJeHaziSnapshot();
          if (cancelled) return;
          if (cloud) {
            setItems(Array.isArray(cloud.items) ? cloud.items : []);
            setProfile({ ...initialProfile, ...(cloud.profile ?? {}) });
            setOnboardingComplete(Boolean(cloud.profile?.name || cloud.profile?.weddingDate));
            setLastSyncedAt(new Date().toISOString());
          } else if (localOnboarding || localItems.length || localProfile.name) {
            await syncSnapshot({ profile: localProfile, items: localItems });
          }
        }
      } catch (error) {
        console.log("[JeHazi] Cloud sync unavailable; continuing offline", error);
        if (queued) setPendingSync(true);
      } finally {
        cloudReady.current = true;
      }
    }
    hydrate();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(items)).catch(() => undefined);
    AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(profile)).catch(() => undefined);
    AsyncStorage.setItem(ONBOARDING_KEY, String(onboardingComplete)).catch(() => undefined);

    if (!cloudReady.current) return;
    if (syncTimer.current) clearTimeout(syncTimer.current);
    syncTimer.current = setTimeout(() => {
      void syncSnapshot({ profile, items });
    }, 900);
    return () => { if (syncTimer.current) clearTimeout(syncTimer.current); };
  }, [items, profile, onboardingComplete, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    let active = true;
    const flush = () => { if (active) void retrySync(); };
    const interval = setInterval(flush, 30_000);
    const subscription = AppState.addEventListener("change", (state) => {
      if (state === "active") flush();
    });
    void hasPendingSync().then(setPendingSync);
    return () => {
      active = false;
      clearInterval(interval);
      subscription.remove();
    };
  }, [hydrated]);

  const value = useMemo<InventoryContextValue>(() => ({
    items,
    profile,
    hydrated,
    onboardingComplete,
    addItem: (item) => setItems((current) => [...current, { ...item, id: `item-${Date.now()}` }]),
    updateItem: (id, patch) => setItems((current) => current.map((item) => item.id === id ? { ...item, ...patch } : item)),
    deleteItem: (id) => setItems((current) => current.filter((item) => item.id !== id)),
    updateProfile: (patch) => setProfile((current) => ({ ...current, ...patch })),
    completeOnboarding: (nextProfile, useStarterList) => {
      setProfile(nextProfile);
      setItems(useStarterList ? seedItems : []);
      setOnboardingComplete(true);
    },
    resetDemo: () => { setItems(seedItems); setProfile(initialProfile); },
    pendingSync,
    lastSyncedAt,
    retrySync,
  }), [items, profile, hydrated, onboardingComplete, pendingSync, lastSyncedAt]);

  return <InventoryContext.Provider value={value}>{children}</InventoryContext.Provider>;
}

const InventoryContext = createContext<InventoryContextValue | null>(null);

export function useInventory() {
  const context = useContext(InventoryContext);
  if (!context) throw new Error("useInventory must be used inside InventoryProvider");
  return context;
}
