export const BRAND = {
  name: 'JEHAZI',
  arabicName: 'جهازي',
  tagline: 'تجهيزك… بهدوء، خطوة بخطوة',
  colors: {
    plum: '#34283A',
    plumSoft: '#8B5E73',
    champagne: '#D6B06A',
    ivory: '#F7F0E6',
    cream: '#FFFDF9',
    sage: '#DDE4D8',
  },
} as const;
