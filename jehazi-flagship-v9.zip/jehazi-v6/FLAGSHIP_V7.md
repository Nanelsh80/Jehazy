# JEHAZI Flagship v7

## Production foundation

- Independent email/password authentication; no Manus OAuth dependency.
- JWT sessions with HttpOnly web cookies and SecureStore on native.
- Local-first inventory remains available during network interruptions.
- Cloud snapshot sync continues automatically after authentication.
- Warranty metadata is now persisted in the cloud snapshot/database.
- Package identity remains `com.jehazi.app` and deep-link scheme `jehazi`.

## Authentication API

- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `POST /api/auth/session`

Passwords use Node's built-in `scrypt` KDF with per-user random salts; plaintext passwords are never stored.

## Data durability

Warranty URI/name/start/end/provider/notes now round-trip through `getJeHaziSnapshot` and `saveJeHaziSnapshot`.

## Environment

Required for production:

- `DATABASE_URL`
- `JWT_SECRET`
- `EXPO_PUBLIC_API_BASE_URL`

Optional:

- `OWNER_EMAIL`

## Verification note

The current execution environment does not provide the project's installed pnpm/node_modules and external package installation is unavailable. Therefore no claim of a successful local TypeScript/Vitest run is made here. Static source review and migration consistency checks were performed.
