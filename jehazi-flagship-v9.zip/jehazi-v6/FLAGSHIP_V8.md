# JEHAZI Flagship v8

## Cloud Storage + Asset Center

This release adds a real S3-compatible cloud asset layer for item photos, receipts/invoices, and warranty cards.

### Delivered
- `jehazi_assets` metadata table.
- Per-item asset IDs for photo/receipt/warranty.
- Short-lived signed PUT uploads.
- Short-lived signed GET URLs refreshed with cloud snapshots.
- Ownership checks on every asset operation.
- Replacement and deletion of one asset per item/kind.
- Local-first fallback when cloud storage is not configured.
- No new third-party runtime package required; signing is implemented with Node crypto.
- Storage provider remains replaceable because it is S3-compatible rather than vendor-locked.

### Architecture
`Expo app -> authenticated API -> signed S3/R2 URL -> object storage`

MySQL stores metadata only; binary files stay in object storage.

### Next flagship gate
Production QA should verify Android upload/download on a real device, offline recovery, session expiry, migration order, and a real S3/R2 bucket before release.
