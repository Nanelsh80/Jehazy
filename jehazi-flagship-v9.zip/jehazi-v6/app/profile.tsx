import { useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { formatMoney, useInventory } from "@/lib/inventory-context";

export default function ProfileScreen() {
  const router = useRouter();
  const { profile, updateProfile } = useInventory();
  const [name, setName] = useState(profile.name);
  const [weddingDate, setWeddingDate] = useState(profile.weddingDate);
  const [budget, setBudget] = useState(String(profile.budget));

  const save = () => {
    if (!name.trim()) {
      Alert.alert("الاسم ناقص", "اكتبي اسمك عشان نكمّل بياناتك.");
      return;
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(weddingDate)) {
      Alert.alert("التاريخ محتاج تعديل", "اكتبي التاريخ بالشكل ده: 2026-12-18");
      return;
    }
    updateProfile({ name: name.trim(), weddingDate, budget: Math.max(Number(budget.replace(/,/g, "")) || 0, 0) });
    Alert.alert("اتحفظت بياناتك", "هنستخدمها عشان نرتب أولويات التجهيز.", [{ text: "تمام", onPress: () => router.back() }]);
  };

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <View style={styles.header}>
            <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.backButton, pressed && styles.pressed]}><MaterialIcons name="arrow-forward" size={22} color="#34283A" /></Pressable>
            <View style={styles.headerCopy}><Text style={styles.kicker}>بيانات التجهيز</Text><Text style={styles.title}>بياناتي وميعاد الفرح</Text></View>
          </View>
          <View style={styles.introCard}><View style={styles.introIcon}><MaterialIcons name="favorite-border" size={23} color="#8B5E73" /></View><View style={styles.introCopy}><Text style={styles.introTitle}>خلّي جهازي يفهم أولوياتك</Text><Text style={styles.introText}>كل ما كانت بياناتك أدق، نقدر نرتّب لكِ المشتريات بشكل أذكى.</Text></View></View>
          <Field label="اسم العروسة" value={name} onChangeText={setName} placeholder="مثال: سارة" />
          <Field label="تاريخ الفرح" value={weddingDate} onChangeText={setWeddingDate} placeholder="2026-12-18" keyboardType="numbers-and-punctuation" hint="استخدمي صيغة السنة-الشهر-اليوم" />
          <Field label="الميزانية الكلية" value={budget} onChangeText={setBudget} placeholder="150000" keyboardType="number-pad" suffix="ج.م" />
          <View style={styles.previewCard}><View style={styles.previewIcon}><MaterialIcons name="savings" size={21} color="#B68A42" /></View><View style={styles.previewCopy}><Text style={styles.previewLabel}>ميزانيتك الحالية</Text><Text style={styles.previewValue}>{formatMoney(Number(budget.replace(/,/g, "")) || 0)}</Text></View></View>
          <Pressable onPress={save} style={({ pressed }) => [styles.saveButton, pressed && styles.pressed]}><MaterialIcons name="check" size={20} color="#FFF9F0" /><Text style={styles.saveText}>حفظ البيانات</Text></Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

function Field({ label, value, onChangeText, placeholder, keyboardType, suffix, hint }: { label: string; value: string; onChangeText: (value: string) => void; placeholder: string; keyboardType?: any; suffix?: string; hint?: string }) {
  return <View style={styles.field}><View style={styles.labelRow}><Text style={styles.label}>{label}</Text>{hint ? <Text style={styles.hint}>{hint}</Text> : null}</View><View style={styles.inputWrap}><TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor="#B0A59D" keyboardType={keyboardType} style={styles.input} textAlign="right" returnKeyType="done" />{suffix ? <Text style={styles.suffix}>{suffix}</Text> : null}</View></View>;
}

const styles = StyleSheet.create({ flex: { flex: 1 }, content: { paddingTop: 18, paddingBottom: 38, writingDirection: "rtl" }, header: { flexDirection: "row-reverse", alignItems: "center", gap: 10, marginBottom: 19 }, backButton: { width: 38, height: 38, borderRadius: 13, backgroundColor: "#F0E7E1", alignItems: "center", justifyContent: "center" }, headerCopy: { flex: 1, alignItems: "flex-end" }, kicker: { color: "#8B5E73", fontSize: 12, fontWeight: "700" }, title: { color: "#34283A", fontSize: 25, lineHeight: 34, fontWeight: "800", marginTop: 2, textAlign: "right" }, introCard: { flexDirection: "row-reverse", alignItems: "center", gap: 11, backgroundColor: "#F2E5DC", borderRadius: 19, padding: 15, marginBottom: 23 }, introIcon: { width: 44, height: 44, borderRadius: 15, backgroundColor: "#FFF7F0", alignItems: "center", justifyContent: "center" }, introCopy: { flex: 1, alignItems: "flex-end" }, introTitle: { color: "#34283A", fontSize: 14, fontWeight: "800", textAlign: "right" }, introText: { color: "#8B7467", fontSize: 11, lineHeight: 18, marginTop: 4, textAlign: "right" }, field: { marginBottom: 17 }, labelRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: 7 }, label: { color: "#5E514A", fontSize: 12, fontWeight: "800", textAlign: "right" }, hint: { color: "#AA9D95", fontSize: 10 }, inputWrap: { minHeight: 50, flexDirection: "row-reverse", alignItems: "center", backgroundColor: "#FFFDFC", borderWidth: 1, borderColor: "#E9DED4", borderRadius: 15, paddingHorizontal: 13 }, input: { flex: 1, color: "#34283A", fontSize: 13, paddingVertical: 0 }, suffix: { color: "#8B5E73", fontSize: 12, fontWeight: "800", marginLeft: 7 }, previewCard: { flexDirection: "row-reverse", alignItems: "center", gap: 10, backgroundColor: "#F4E9D8", borderRadius: 18, padding: 15, marginTop: 3, marginBottom: 18 }, previewIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#F0E2C4", alignItems: "center", justifyContent: "center" }, previewCopy: { flex: 1, alignItems: "flex-end" }, previewLabel: { color: "#7C6950", fontSize: 11, textAlign: "right" }, previewValue: { color: "#5B4854", fontSize: 18, fontWeight: "800", marginTop: 3, textAlign: "right" }, saveButton: { height: 53, borderRadius: 17, backgroundColor: "#8B5E73", flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 7, shadowColor: "#8B5E73", shadowOpacity: 0.2, shadowRadius: 9, shadowOffset: { width: 0, height: 4 }, elevation: 3 }, saveText: { color: "#FFF9F0", fontSize: 15, fontWeight: "800" }, pressed: { opacity: 0.7 },
});
