import { useState } from "react";
import { Alert, Pressable, StyleSheet, Switch, Text, View } from "react-native";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useInventory } from "@/lib/inventory-context";
import { cancelScheduledNotifications, scheduleWeddingReminders } from "@/lib/notifications";

export default function NotificationsScreen() {
  const router = useRouter();
  const { profile } = useInventory();
  const [enabled, setEnabled] = useState(false);
  const [busy, setBusy] = useState(false);

  async function toggle(value: boolean) {
    setBusy(true);
    try {
      if (value) {
        const count = await scheduleWeddingReminders(profile.weddingDate);
        if (!count) {
          Alert.alert("محتاجين تاريخ صحيح", "اكتبي تاريخ الفرح من بياناتك أولًا، أو تأكدي أن الموعد ما زال في المستقبل.");
          setEnabled(false);
          return;
        }
        setEnabled(true);
        Alert.alert("التنبيهات اتفعلت ✨", `جهزت لكِ ${count} تذكيرات قبل الفرح.`);
      } else {
        await cancelScheduledNotifications();
        setEnabled(false);
      }
    } finally { setBusy(false); }
  }

  return <ScreenContainer className="px-5" containerClassName="bg-background"><View style={styles.page}>
    <View style={styles.header}><Pressable onPress={() => router.back()} style={styles.back}><MaterialIcons name="arrow-forward" size={21} color="#34283A" /></Pressable><View style={styles.headerCopy}><Text style={styles.kicker}>ابقَي على المسار</Text><Text style={styles.title}>التنبيهات والتذكيرات</Text></View></View>
    <View style={styles.hero}><View style={styles.icon}><MaterialIcons name="notifications-active" size={26} color="#D6B06A" /></View><View style={styles.copy}><Text style={styles.heroTitle}>جهازي يفتكّرك في الوقت المناسب</Text><Text style={styles.heroText}>تنبيهات محلية على هاتفك لمواعيد التجهيز والاقتراب من موعد الفرح.</Text></View></View>
    <View style={styles.row}><View style={styles.rowIcon}><MaterialIcons name="event" size={21} color="#8B5E73" /></View><View style={styles.rowCopy}><Text style={styles.rowTitle}>تذكيرات موعد الفرح</Text><Text style={styles.rowText}>قبل 30 و14 و7 ويوم واحد من الموعد.</Text></View><Switch value={enabled} onValueChange={toggle} disabled={busy} trackColor={{ false: "#DDD3CC", true: "#B68A8B" }} thumbColor={enabled ? "#8B5E73" : "#FFFDF9"} /></View>
    <View style={styles.note}><MaterialIcons name="shield" size={18} color="#8B5E73" /><Text style={styles.noteText}>التنبيهات محلية على جهازك، ويمكن إيقافها في أي وقت.</Text></View>
  </View></ScreenContainer>;
}
const styles = StyleSheet.create({ page: { flex: 1, paddingTop: 18, writingDirection: "rtl" }, header: { flexDirection: "row-reverse", alignItems: "center", gap: 10, marginBottom: 18 }, back: { width: 38, height: 38, borderRadius: 13, backgroundColor: "#F0E7E1", alignItems: "center", justifyContent: "center" }, headerCopy: { flex: 1, alignItems: "flex-end" }, kicker: { color: "#8B5E73", fontSize: 12, fontWeight: "700" }, title: { color: "#34283A", fontSize: 25, fontWeight: "800", marginTop: 2, textAlign: "right" }, hero: { flexDirection: "row-reverse", alignItems: "center", gap: 12, backgroundColor: "#34283A", borderRadius: 22, padding: 17, marginBottom: 15 }, icon: { width: 50, height: 50, borderRadius: 17, backgroundColor: "#4A3A50", alignItems: "center", justifyContent: "center" }, copy: { flex: 1, alignItems: "flex-end" }, heroTitle: { color: "#FFF8F0", fontSize: 15, fontWeight: "800", textAlign: "right" }, heroText: { color: "#DCCFD9", fontSize: 10, lineHeight: 17, marginTop: 4, textAlign: "right" }, row: { flexDirection: "row-reverse", alignItems: "center", gap: 11, backgroundColor: "#FFFDFC", borderRadius: 19, padding: 14 }, rowIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#F0E5EA", alignItems: "center", justifyContent: "center" }, rowCopy: { flex: 1, alignItems: "flex-end" }, rowTitle: { color: "#34283A", fontSize: 13, fontWeight: "800", textAlign: "right" }, rowText: { color: "#978B84", fontSize: 10, lineHeight: 16, marginTop: 4, textAlign: "right" }, note: { flexDirection: "row-reverse", alignItems: "center", gap: 8, backgroundColor: "#F4E9D8", borderRadius: 16, padding: 12, marginTop: 12 }, noteText: { flex: 1, color: "#7C6950", fontSize: 10, lineHeight: 16, textAlign: "right" } });
