import { useMemo } from "react";
import { FlatList, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { CATEGORY_META, CategoryKey, categoryProgress, daysUntilWedding, formatMoney, overallProgress, remainingQty, budgetTotals, preparationInsights, weeklyPreparationPlan, useInventory } from "@/lib/inventory-context";

const categoryOrder: CategoryKey[] = ["device", "clothes", "bedding", "small"];

export default function HomeScreen() {
  const router = useRouter();
  const { items, profile, pendingSync, lastSyncedAt, retrySync } = useInventory();
  const days = daysUntilWedding(profile.weddingDate);
  const activeItems = items.filter((item) => item.status !== "notNeeded");
  const totalRequired = activeItems.reduce((sum, item) => sum + item.requiredQty, 0);
  const owned = activeItems.reduce((sum, item) => sum + Math.min(item.ownedQty, item.requiredQty), 0);
  const overall = overallProgress(items);
  const { estimated: totalEstimate, paid } = budgetTotals(items);
  const insights = useMemo(() => preparationInsights(items, profile), [items, profile]);
  const weeklyPlan = useMemo(() => weeklyPreparationPlan(items, profile), [items, profile]);
  const attention = useMemo(() => items.filter((item) => remainingQty(item) > 0 && item.status !== "notNeeded").sort((a, b) => priorityScore(b.priority) - priorityScore(a.priority)).slice(0, 4), [items]);

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <View style={styles.headerCopy}>
            <View style={styles.brandLine}><Text style={styles.brandWord}>JEHAZI</Text><Text style={styles.eyebrow}>مساء الخير يا {profile.name} ✨</Text></View>
            <Text style={styles.title}>خلّي جهازك على مزاجك</Text>
          </View>
          <Pressable onPress={() => router.push("/more")} style={({ pressed }) => [styles.avatar, pressed && styles.pressed]}>
            <Text style={styles.avatarText}>{profile.name.slice(0, 1)}</Text>
          </Pressable>
        </View>

        <View style={styles.dateRow}>
          <MaterialIcons name="event" size={17} color="#8B5E73" />
          <Text style={styles.dateText}>ميعاد فرحك {formatDate(profile.weddingDate)}</Text>
          <View style={styles.dateDivider} />
          <Text style={styles.daysText}>{days} يوم باقي</Text>
        </View>

        <View style={[styles.syncBanner, pendingSync ? styles.syncPending : styles.syncReady]}>
          <MaterialIcons name={pendingSync ? "cloud-upload" : "cloud-done"} size={18} color={pendingSync ? "#B7863F" : "#527E67"} />
          <View style={styles.syncCopy}>
            <Text style={styles.syncTitle}>{pendingSync ? "في تغييرات مستنية المزامنة" : "بياناتك متزامنة"}</Text>
            <Text style={styles.syncDetail}>{pendingSync ? "هنحاول تلقائيًا لما الاتصال يرجع" : lastSyncedAt ? `آخر مزامنة ${new Date(lastSyncedAt).toLocaleTimeString("ar-EG", { hour: "numeric", minute: "2-digit" })}` : "المزامنة السحابية جاهزة"}</Text>
          </View>
          {pendingSync && <Pressable onPress={() => void retrySync()} style={styles.syncAction}><Text style={styles.syncActionText}>إعادة</Text></Pressable>}
        </View>

        <View style={styles.commandCard}>
          <View style={styles.commandHeader}>
            <View style={styles.commandBadge}><MaterialIcons name="dashboard-customize" size={17} color="#34283A" /></View>
            <View style={styles.commandCopy}><Text style={styles.commandKicker}>BRIDE COMMAND CENTER</Text><Text style={styles.commandTitle}>صورتك الكاملة اليوم</Text></View>
          </View>
          <View style={styles.commandGrid}>
            <CommandStat icon="shopping-cart" value={String(activeItems.filter((item) => remainingQty(item) > 0).length)} label="محتاج شراء" />
            <CommandStat icon="local-shipping" value={String(activeItems.filter((item) => item.status === "shipping" || item.status === "reserved").length)} label="طلبات متابعة" />
            <CommandStat icon="warning" value={String(activeItems.filter((item) => item.priority === "high" && remainingQty(item) > 0).length)} label="أولوية عالية" />
            <CommandStat icon="savings" value={formatMoney(Math.max(profile.budget - paid, 0))} label="متاح للإنفاق" />
          </View>
        </View>

        <View style={styles.heroCard}>
          <View style={styles.heroTop}>
            <View>
              <Text style={styles.heroLabel}>نسبة التجهيز الكلية</Text>
              <Text style={styles.heroTitle}>{overall}% <Text style={styles.heroTitleLight}>جاهزة</Text></Text>
            </View>
            <View style={styles.heroRing}><Text style={styles.heroRingText}>{totalRequired}</Text><Text style={styles.heroRingLabel}>قطعة</Text></View>
          </View>
          <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${Math.max(overall, 4)}%` }]} /></View>
          <View style={styles.heroStats}>
            <View><Text style={styles.statValue}>{owned}</Text><Text style={styles.statLabel}>تم تجهيزها</Text></View>
            <View><Text style={[styles.statValue, styles.errorText]}>{activeItems.filter((item) => remainingQty(item) > 0).length}</Text><Text style={styles.statLabel}>لسه ناقص</Text></View>
            <View><Text style={styles.statValue}>{formatMoney(totalEstimate)}</Text><Text style={styles.statLabel}>التكلفة المتوقعة</Text></View>
          </View>
        </View>

        <View style={styles.smartCard}>
          <View style={styles.smartHeader}><MaterialIcons name="auto-awesome" size={20} color="#B7863F" /><Text style={styles.smartTitle}>مساعد جهازي الذكي</Text></View>
          {insights.map((insight) => <View key={insight.id} style={styles.insightRow}><View style={styles.insightIcon}><MaterialIcons name={insight.icon as any} size={18} color="#8B5E73" /></View><View style={styles.insightCopy}><Text style={styles.insightTitle}>{insight.title}</Text><Text style={styles.insightDetail}>{insight.detail}</Text></View></View>)}
        </View>

        <View style={styles.planCard}>
          <View style={styles.planHeader}><View style={styles.planBadge}><MaterialIcons name="auto-awesome" size={15} color="#34283A" /></View><View style={styles.planHeaderCopy}><Text style={styles.planKicker}>JEHAZI SMART PLAN</Text><Text style={styles.planTitle}>خطة الأسبوع</Text></View></View>
          {weeklyPlan.map((step, index) => <View key={step.title} style={styles.planRow}><View style={styles.planNumber}><Text style={styles.planNumberText}>{index + 1}</Text></View><View style={styles.planCopy}><Text style={styles.planStep}>{step.title}</Text><Text style={styles.planDetail}>{step.detail}</Text></View><MaterialIcons name={step.icon as any} size={19} color="#8B5E73" /></View>)}
        </View>

        <View style={styles.sectionHeading}><Text style={styles.sectionTitle}>أقسام جهازي</Text><Text style={styles.sectionHint}>اختاري القسم</Text></View>
        <View style={styles.categoryGrid}>
          {categoryOrder.map((category) => {
            const meta = CATEGORY_META[category];
            const progress = categoryProgress(items, category);
            const count = items.filter((item) => item.category === category).length;
            return (
              <Pressable key={category} onPress={() => router.push({ pathname: "/category/[category]", params: { category } })} style={({ pressed }) => [styles.categoryCard, { backgroundColor: meta.soft }, pressed && styles.cardPressed]}>
                <View style={[styles.categoryIcon, { backgroundColor: "rgba(255,255,255,0.65)" }]}><MaterialIcons name={meta.icon as any} size={25} color={meta.tint} /></View>
                <Text style={styles.categoryName}>{meta.label}</Text>
                <Text style={styles.categoryCount}>{count} عناصر • {progress}%</Text>
                <View style={styles.smallTrack}><View style={[styles.smallFill, { width: `${Math.max(progress, 5)}%`, backgroundColor: meta.tint }]} /></View>
              </Pressable>
            );
          })}
        </View>

        <View style={styles.sectionHeading}><Text style={styles.sectionTitle}>أهم ما يحتاج انتباهك</Text><Pressable onPress={() => router.push("/purchases")}><Text style={styles.linkText}>عرض الكل</Text></Pressable></View>
        <View style={styles.attentionCard}>
          {attention.length === 0 ? <Text style={styles.emptyText}>كل حاجة ماشية تمام، برافو عليكِ!</Text> : <FlatList data={attention} scrollEnabled={false} keyExtractor={(item) => item.id} renderItem={({ item, index }) => (
            <Pressable onPress={() => router.push({ pathname: "/item/[id]", params: { id: item.id } })} style={({ pressed }) => [styles.attentionRow, pressed && styles.pressed]}>
              <View style={[styles.priorityDot, { backgroundColor: item.priority === "high" ? "#BC5C58" : item.priority === "medium" ? "#B7863F" : "#607D68" }]} />
              <View style={styles.attentionCopy}><Text style={styles.attentionName}>{remainingQty(item)} {item.name}</Text><Text style={styles.attentionMeta}>{CATEGORY_META[item.category].label} • {item.room}</Text></View>
              <MaterialIcons name="chevron-left" size={20} color="#B7AAA1" />
              {index < attention.length - 1 && <View style={styles.rowDivider} />}
            </Pressable>
          )} />}
        </View>

        <View style={styles.quickRow}>
          <Pressable onPress={() => router.push("/item/new")} style={({ pressed }) => [styles.quickButton, pressed && styles.pressed]}><MaterialIcons name="add-circle-outline" size={20} color="#8B5E73" /><Text style={styles.quickText}>إضافة قطعة</Text></Pressable>
          <Pressable onPress={() => router.push("/purchases")} style={({ pressed }) => [styles.quickButton, pressed && styles.pressed]}><MaterialIcons name="shopping-cart" size={20} color="#607D68" /><Text style={styles.quickText}>قائمة المشتريات</Text></Pressable>
        </View>

        <View style={styles.balanceCard}><View><Text style={styles.balanceLabel}>المتبقي من ميزانيتك</Text><Text style={styles.balanceValue}>{formatMoney(Math.max(profile.budget - paid, 0))}</Text></View><View style={styles.balanceIcon}><MaterialIcons name="savings" size={25} color="#B68A42" /></View></View>
      </ScrollView>
    </ScreenContainer>
  );
}

function CommandStat({ icon, value, label }: { icon: any; value: string; label: string }) {
  return <View style={styles.commandStat}><View style={styles.commandIcon}><MaterialIcons name={icon} size={16} color="#8B5E73" /></View><Text style={styles.commandValue} numberOfLines={1}>{value}</Text><Text style={styles.commandLabel}>{label}</Text></View>;
}

function priorityScore(priority: string) { return priority === "high" ? 3 : priority === "medium" ? 2 : 1; }
function formatDate(value: string) { return new Date(`${value}T12:00:00`).toLocaleDateString("ar-EG", { day: "numeric", month: "long" }); }

const styles = StyleSheet.create({
  syncBanner: { flexDirection: "row-reverse", alignItems: "center", gap: 9, borderRadius: 16, padding: 11, marginBottom: 12 },
  syncPending: { backgroundColor: "#F8EEDC", borderWidth: 1, borderColor: "#E9D7B5" },
  syncReady: { backgroundColor: "#EAF2EC", borderWidth: 1, borderColor: "#D4E5D8" },
  syncCopy: { flex: 1, alignItems: "flex-end" }, syncTitle: { color: "#4B403A", fontSize: 11, fontWeight: "900", textAlign: "right" }, syncDetail: { color: "#8B7B70", fontSize: 9, marginTop: 2, textAlign: "right" },
  syncAction: { paddingHorizontal: 11, paddingVertical: 6, borderRadius: 10, backgroundColor: "#FFFDF9" }, syncActionText: { color: "#8B5E73", fontSize: 10, fontWeight: "900" },
  commandCard: { backgroundColor: "#FFFDF9", borderRadius: 22, padding: 15, marginBottom: 18, borderWidth: 1, borderColor: "#E9DDD2", shadowColor: "#34283A", shadowOpacity: 0.05, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 2 },
  commandHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 10, marginBottom: 14 }, commandBadge: { width: 34, height: 34, borderRadius: 12, backgroundColor: "#F0E2C4", alignItems: "center", justifyContent: "center" }, commandCopy: { flex: 1, alignItems: "flex-end" }, commandKicker: { color: "#B7863F", fontSize: 8, letterSpacing: 1.1, fontWeight: "900" }, commandTitle: { color: "#34283A", fontSize: 15, fontWeight: "900", marginTop: 2 },
  commandGrid: { flexDirection: "row-reverse", justifyContent: "space-between", gap: 7 }, commandStat: { flex: 1, alignItems: "flex-end", backgroundColor: "#F8F1EA", borderRadius: 14, padding: 9, minWidth: 0 }, commandIcon: { width: 27, height: 27, borderRadius: 9, backgroundColor: "#FFFDF9", alignItems: "center", justifyContent: "center", alignSelf: "flex-end" }, commandValue: { color: "#34283A", fontSize: 12, fontWeight: "900", marginTop: 7, maxWidth: "100%" }, commandLabel: { color: "#8A7D75", fontSize: 8, marginTop: 2, textAlign: "right" },
  scrollContent: { paddingTop: 20, paddingBottom: 34, writingDirection: "rtl" },
  header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: 14 },
  headerCopy: { alignItems: "flex-end" },
  eyebrow: { color: "#8B5E73", fontSize: 14, fontWeight: "700", marginBottom: 5 },
  title: { color: "#34283A", fontSize: 25, lineHeight: 32, fontWeight: "800" },
  avatar: { width: 45, height: 45, borderRadius: 23, backgroundColor: "#D9B6A7", alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: "#FFFDFC" },
  avatarText: { color: "#70483A", fontSize: 20, fontWeight: "800" },
  dateRow: { flexDirection: "row-reverse", alignItems: "center", gap: 7, marginBottom: 18 },
  dateText: { color: "#867D76", fontSize: 13, fontWeight: "600" },
  dateDivider: { width: 1, height: 15, backgroundColor: "#D9CCC1", marginHorizontal: 3 },
  daysText: { color: "#B7863F", fontSize: 13, fontWeight: "800" },
  heroCard: { backgroundColor: "#34283A", borderRadius: 25, padding: 20, marginBottom: 25, shadowColor: "#34283A", shadowOpacity: 0.18, shadowRadius: 16, shadowOffset: { width: 0, height: 8 }, elevation: 4 },
  heroTop: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" },
  heroLabel: { color: "#E5D6C8", fontSize: 13, textAlign: "right", marginBottom: 5 },
  heroTitle: { color: "#FFF9F0", fontSize: 35, lineHeight: 42, fontWeight: "800", textAlign: "right" },
  heroTitleLight: { color: "#EEDBD0", fontSize: 19, fontWeight: "600" },
  heroRing: { width: 61, height: 61, borderRadius: 32, borderWidth: 1.5, borderColor: "#DABCA9", alignItems: "center", justifyContent: "center" },
  heroRingText: { color: "#FFF9F0", fontSize: 17, fontWeight: "800" }, heroRingLabel: { color: "#E5D6C8", fontSize: 10 },
  progressTrack: { height: 7, borderRadius: 6, backgroundColor: "#665565", marginTop: 18, overflow: "hidden" },
  progressFill: { height: "100%", borderRadius: 6, backgroundColor: "#D6B06A" },
  heroStats: { flexDirection: "row-reverse", justifyContent: "space-between", marginTop: 20 },
  statValue: { color: "#FFF9F0", fontSize: 16, fontWeight: "800", textAlign: "right" }, statLabel: { color: "#DCCAC0", fontSize: 11, marginTop: 3, textAlign: "right" }, errorText: { color: "#F5C1B4" },
  smartCard: { backgroundColor: "#F4E9D8", borderRadius: 21, padding: 16, marginBottom: 24 },
  smartHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 8, marginBottom: 12 }, smartTitle: { color: "#5B4854", fontSize: 15, fontWeight: "800", textAlign: "right", flex: 1 }, insightRow: { flexDirection: "row-reverse", alignItems: "flex-start", gap: 10, marginBottom: 11 }, insightIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: "#F0E2C4", alignItems: "center", justifyContent: "center" }, insightCopy: { flex: 1, alignItems: "flex-end" }, insightTitle: { color: "#4A3B4A", fontSize: 12, fontWeight: "800", textAlign: "right" }, insightDetail: { color: "#77624B", fontSize: 11, lineHeight: 17, marginTop: 3, textAlign: "right" },
  sectionHeading: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  sectionTitle: { color: "#34283A", fontSize: 18, fontWeight: "800" }, sectionHint: { color: "#A59A92", fontSize: 12 }, linkText: { color: "#8B5E73", fontSize: 12, fontWeight: "800" },
  categoryGrid: { flexDirection: "row-reverse", flexWrap: "wrap", justifyContent: "space-between", marginBottom: 25 },
  categoryCard: { width: "48.2%", borderRadius: 20, padding: 14, marginBottom: 12, minHeight: 132 },
  categoryIcon: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center", alignSelf: "flex-end", marginBottom: 11 },
  categoryName: { color: "#34283A", fontSize: 16, fontWeight: "800", textAlign: "right" }, categoryCount: { color: "#766D67", fontSize: 11, marginTop: 4, textAlign: "right" },
  smallTrack: { height: 4, backgroundColor: "rgba(255,255,255,0.7)", borderRadius: 4, marginTop: 12, overflow: "hidden" }, smallFill: { height: "100%", borderRadius: 4 },
  attentionCard: { backgroundColor: "#FFFDFC", borderRadius: 21, paddingHorizontal: 15, shadowColor: "#634A3C", shadowOpacity: 0.05, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 2, marginBottom: 15 },
  attentionRow: { minHeight: 65, flexDirection: "row-reverse", alignItems: "center", gap: 10, position: "relative" },
  priorityDot: { width: 9, height: 9, borderRadius: 5 }, attentionCopy: { flex: 1, alignItems: "flex-end" }, attentionName: { color: "#3B3040", fontSize: 14, fontWeight: "800" }, attentionMeta: { color: "#998E86", fontSize: 11, marginTop: 4 }, rowDivider: { height: 1, backgroundColor: "#F0E9E3", position: "absolute", bottom: 0, left: 19, right: 0 }, emptyText: { color: "#607D68", textAlign: "center", padding: 22, fontSize: 14, fontWeight: "700" },
  quickRow: { flexDirection: "row-reverse", gap: 10, marginBottom: 15 }, quickButton: { flex: 1, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 7, backgroundColor: "#F0E5EA", borderRadius: 15, paddingVertical: 13 }, quickText: { color: "#34283A", fontSize: 12, fontWeight: "800" },
  balanceCard: { backgroundColor: "#F4E9D8", borderRadius: 19, padding: 17, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }, balanceLabel: { color: "#7C6950", fontSize: 12, textAlign: "right" }, balanceValue: { color: "#5B4854", fontSize: 20, fontWeight: "800", marginTop: 4, textAlign: "right" }, balanceIcon: { width: 46, height: 46, borderRadius: 16, backgroundColor: "#F0E2C4", alignItems: "center", justifyContent: "center" },
  planCard: { backgroundColor: "#FFFDF9", borderRadius: 22, padding: 16, marginBottom: 24, borderWidth: 1, borderColor: "#E7DCD0", shadowColor: "#34283A", shadowOpacity: 0.06, shadowRadius: 14, shadowOffset: { width: 0, height: 5 }, elevation: 2 }, planHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 10, marginBottom: 14 }, planBadge: { width: 34, height: 34, borderRadius: 12, backgroundColor: "#F0E2C4", alignItems: "center", justifyContent: "center" }, planHeaderCopy: { flex: 1, alignItems: "flex-end" }, planKicker: { color: "#B7863F", fontSize: 9, letterSpacing: 1.4, fontWeight: "900" }, planTitle: { color: "#34283A", fontSize: 17, fontWeight: "900", marginTop: 2 }, planRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10, paddingVertical: 9, borderTopWidth: 1, borderTopColor: "#F0E8DE" }, planNumber: { width: 28, height: 28, borderRadius: 10, backgroundColor: "#F4E9EA", alignItems: "center", justifyContent: "center" }, planNumberText: { color: "#8B5E73", fontSize: 12, fontWeight: "900" }, planCopy: { flex: 1, alignItems: "flex-end" }, planStep: { color: "#433745", fontSize: 12, fontWeight: "900", textAlign: "right" }, planDetail: { color: "#83777D", fontSize: 11, lineHeight: 17, marginTop: 2, textAlign: "right" },
  pressed: { opacity: 0.72 }, cardPressed: { transform: [{ scale: 0.98 }], opacity: 0.9 },
});
