import { Alert, Pressable, StyleSheet, Text, View } from "react-native";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useRouter } from "expo-router";
import { useInventory } from "@/lib/inventory-context";
import { useAuth } from "@/hooks/use-auth";
import { ScreenContainer } from "@/components/screen-container";

export default function MoreScreen() {
  const router = useRouter();
  const { profile, resetDemo } = useInventory();
  const { user, logout } = useAuth();
  const showComingSoon = () => Alert.alert("قريبًا", "الميزة دي هتكون متاحة في التحديث الجاي.");
  return <ScreenContainer className="px-5" containerClassName="bg-background"><View style={styles.page}>
    <Text style={styles.kicker}>مساحتك الخاصة</Text><Text style={styles.title}>المزيد</Text>
    <Pressable onPress={() => router.push("/profile")} style={({ pressed }) => [styles.profileCard, pressed && styles.pressed]}><View style={styles.avatar}><Text style={styles.avatarText}>{profile.name.slice(0, 1)}</Text></View><View style={styles.profileCopy}><Text style={styles.greeting}>أهلاً يا</Text><Text style={styles.name}>{profile.name}</Text><Text style={styles.small}>جاهزة تكملي تجهيزك؟</Text></View><MaterialIcons name="edit" size={19} color="#8B5E73" /></Pressable>
    <Text style={styles.sectionTitle}>إعدادات التطبيق</Text>
    <MenuRow icon="person-outline" title="بياناتي وميعاد الفرح" subtitle="عدّلي اسمك أو تاريخ فرحك" onPress={() => router.push("/profile")} />
    <MenuRow icon="lock-outline" title="خصوصية الملابس الداخلية" subtitle="إخفاء القسم برمز سري" onPress={showComingSoon} />
    <MenuRow icon="notifications-none" title="التنبيهات والتذكيرات" subtitle="تذكير بالمشتريات والتسليم" onPress={() => router.push("/notifications")} />
    <MenuRow icon="verified-user" title="مركز الضمانات" subtitle="بطاقات الضمان ومواعيد الانتهاء" onPress={() => router.push("/warranty")} />
    <MenuRow icon="photo-library" title="معرض الصور والإيصالات" subtitle="كل مستندات جهازك في مكان واحد" onPress={showComingSoon} />
    <Text style={styles.sectionTitle}>الحساب</Text>
    <MenuRow icon="email" title={user?.email || "الحساب"} subtitle="الحساب مستقل وآمن" onPress={() => Alert.alert("الحساب", user?.email || "غير مسجل")} />
    <MenuRow icon="logout" title="تسجيل الخروج" subtitle="الخروج من هذا الجهاز" onPress={() => Alert.alert("تسجيل الخروج؟", "بياناتك المحلية تظل محفوظة على الجهاز.", [{ text: "إلغاء", style: "cancel" }, { text: "خروج", style: "destructive", onPress: logout }])} />
    <Text style={styles.sectionTitle}>مساعدة</Text>
    <MenuRow icon="help-outline" title="عن جهازي" subtitle="JEHAZI Flagship 1.4.0" onPress={showComingSoon} />
    <Pressable onPress={() => Alert.alert("إعادة البيانات التجريبية؟", "هنرجّع بيانات العرض زي ما كانت.", [{ text: "إلغاء", style: "cancel" }, { text: "إعادة", onPress: resetDemo }])} style={({ pressed }) => [styles.resetButton, pressed && styles.pressed]}><MaterialIcons name="restart-alt" size={18} color="#BC5C58" /><Text style={styles.resetText}>إعادة بيانات العرض</Text></Pressable>
  </View></ScreenContainer>;
}
function MenuRow({ icon, title, subtitle, onPress }: { icon: any; title: string; subtitle: string; onPress: () => void }) { return <Pressable onPress={onPress} style={({ pressed }) => [styles.menuRow, pressed && styles.pressed]}><View style={styles.menuIcon}><MaterialIcons name={icon} size={21} color="#8B5E73" /></View><View style={styles.menuCopy}><Text style={styles.menuTitle}>{title}</Text><Text style={styles.menuSubtitle}>{subtitle}</Text></View><MaterialIcons name="chevron-left" size={20} color="#B7AAA1" /></Pressable>; }
const styles = StyleSheet.create({ page: { flex: 1, paddingTop: 20, writingDirection: "rtl" }, kicker: { color: "#8B5E73", fontSize: 13, fontWeight: "700", textAlign: "right" }, title: { color: "#34283A", fontSize: 27, lineHeight: 35, fontWeight: "800", textAlign: "right", marginBottom: 19 }, profileCard: { flexDirection: "row-reverse", alignItems: "center", gap: 11, padding: 15, backgroundColor: "#F2E5DC", borderRadius: 20, marginBottom: 25 }, avatar: { width: 49, height: 49, borderRadius: 25, backgroundColor: "#D9B6A7", alignItems: "center", justifyContent: "center" }, avatarText: { color: "#70483A", fontSize: 21, fontWeight: "800" }, profileCopy: { flex: 1, alignItems: "flex-end" }, greeting: { color: "#8B7467", fontSize: 11 }, name: { color: "#34283A", fontSize: 18, fontWeight: "800", marginTop: 2 }, small: { color: "#9C867A", fontSize: 11, marginTop: 3 }, sectionTitle: { color: "#34283A", fontSize: 16, fontWeight: "800", textAlign: "right", marginBottom: 9, marginTop: 2 }, menuRow: { flexDirection: "row-reverse", alignItems: "center", gap: 11, minHeight: 67, backgroundColor: "#FFFDFC", borderRadius: 17, paddingHorizontal: 13, marginBottom: 8 }, menuIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: "#F0E5EA", alignItems: "center", justifyContent: "center" }, menuCopy: { flex: 1, alignItems: "flex-end" }, menuTitle: { color: "#403732", fontSize: 13, fontWeight: "800", textAlign: "right" }, menuSubtitle: { color: "#9A8E86", fontSize: 10, marginTop: 4, textAlign: "right" }, resetButton: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 7, padding: 15, marginTop: 18 }, resetText: { color: "#BC5C58", fontSize: 12, fontWeight: "800" }, pressed: { opacity: 0.68 },
});
