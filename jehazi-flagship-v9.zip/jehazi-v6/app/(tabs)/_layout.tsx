import { Tabs } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Platform, View } from 'react-native';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useColors } from '@/hooks/use-colors';
import { HapticTab } from '@/components/haptic-tab';

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === 'web' ? 10 : Math.max(insets.bottom, 8);
  return (
    <Tabs screenOptions={{
      headerShown: false,
      tabBarActiveTintColor: colors.primary,
      tabBarInactiveTintColor: colors.muted,
      tabBarButton: HapticTab,
      tabBarLabelStyle: { fontFamily: 'System', fontSize: 11, fontWeight: '700', marginTop: 2 },
      tabBarStyle: { height: 64 + bottomPadding, paddingTop: 9, paddingBottom: bottomPadding, paddingHorizontal: 8, backgroundColor: colors.surface, borderTopColor: colors.border, borderTopWidth: 1, elevation: 12, shadowOpacity: 0.08, shadowRadius: 18, shadowOffset: { width: 0, height: -4 } },
    }}>
      <Tabs.Screen name='index' options={{ title: 'الرئيسية', tabBarIcon: ({ color }) => <MaterialIcons name='home-filled' size={23} color={color} /> }} />
      <Tabs.Screen name='purchases' options={{ title: 'المشتريات', tabBarIcon: ({ color }) => <MaterialIcons name='shopping-bag' size={22} color={color} /> }} />
      <Tabs.Screen name='budget' options={{ title: 'الميزانية', tabBarIcon: ({ color }) => <MaterialIcons name='account-balance-wallet' size={22} color={color} /> }} />
      <Tabs.Screen name='more' options={{ title: 'المزيد', tabBarIcon: ({ color }) => <MaterialIcons name='auto-awesome' size={22} color={color} /> }} />
    </Tabs>
  );
}
