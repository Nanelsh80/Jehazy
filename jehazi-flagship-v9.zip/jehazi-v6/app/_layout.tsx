import "../global.css";
import { Redirect, Stack, useSegments } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { ThemeProvider } from "@/lib/theme-provider";
import { InventoryProvider, useInventory } from "@/lib/inventory-context";
import { useAuth } from "@/hooks/use-auth";

export default function RootLayout() {
  return (
    <ThemeProvider>
      <InventoryProvider>
        <AppNavigator />
      </InventoryProvider>
    </ThemeProvider>
  );
}

function AppNavigator() {
  const { hydrated, onboardingComplete } = useInventory();
  const { isAuthenticated, loading: authLoading } = useAuth();
  const segments = useSegments();
  const onOnboarding = segments[0] === "onboarding";
  const onAuth = segments[0] === "auth";

  if (!hydrated || authLoading) return null;
  if (!isAuthenticated && !onAuth) return <Redirect href="/auth" />;
  if (isAuthenticated && onAuth) return <Redirect href={onboardingComplete ? "/(tabs)" : "/onboarding?step=profile"} />;
  if (!onboardingComplete && !onOnboarding) return <Redirect href="/onboarding?step=profile" />;
  if (onboardingComplete && onOnboarding) return <Redirect href="/(tabs)" />;

  return <>
    <StatusBar style="dark" />
    <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: "#F7F0E6" } }}>
      <Stack.Screen name="auth" options={{ gestureEnabled: false }} />
      <Stack.Screen name="onboarding" options={{ gestureEnabled: false }} />
    </Stack>
  </>;
}
