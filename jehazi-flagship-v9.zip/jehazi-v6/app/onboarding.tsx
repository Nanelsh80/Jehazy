import { useEffect, useState } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useLocalSearchParams, useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { isValidWeddingDate, useInventory } from "@/lib/inventory-context";
import { onboardingStepFromParam, ONBOARDING_STEPS, shouldUseStarterList, type OnboardingStep } from "@/lib/onboarding";

const steps = ONBOARDING_STEPS;

export default function OnboardingScreen() {
  const router = useRouter();
  const { step: requestedStep } = useLocalSearchParams<{ step?: string }>();
  const { completeOnboarding } = useInventory();
  const [step, setStep] = useState<OnboardingStep>(() => onboardingStepFromParam(requestedStep));
  const [name, setName] = useState("");
  const [weddingDate, setWeddingDate] = useState("");
  const [started, setStarted] = useState<boolean | null>(null);
  const [starterList, setStarterList] = useState<boolean | null>(null);
  const [budgetEnabled, setBudgetEnabled] = useState(true);
  const [budget, setBudget] = useState("");

  useEffect(() => {
    setStep(onboardingStepFromParam(requestedStep));
  }, [requestedStep]);

  const openProfileStep = () => {
    setStep("profile");
    router.push({ pathname: "/onboarding", params: { step: "profile" } });
  };

  const finish = () => {
    if (!name.trim() || !isValidWeddingDate(weddingDate)) {
      Alert.alert("بيانات ناقصة", "اكتبي اسمك وتاريخ الفرح بصيغة 2026-12-18.");
      return;
    }
    completeOnboarding({ name: name.trim(), weddingDate, budget: budgetEnabled ? Math.max(Number(budget.replace(/,/g, "")) || 0, 0) : 0 }, shouldUseStarterList(starterList));
    router.replace("/(tabs)");
  };

  return <ScreenContainer edges={["top", "bottom", "left", "right"]} className="px-5" containerClassName="bg-background"><ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <View style={styles.brand}><View style={styles.brandMark}><MaterialIcons name="auto-awesome" size={22} color="#B68A42" /></View><Text style={styles.brandText}>جهازي</Text></View>
    <View style={styles.stepper}>{steps.map((entry, index) => <View key={entry} style={styles.stepItem}><View style={[styles.stepDot, (steps.indexOf(step) >= index) && styles.stepDotActive]}><Text style={[styles.stepNumber, (steps.indexOf(step) >= index) && styles.stepNumberActive]}>{index + 1}</Text></View>{index < steps.length - 1 && <View style={[styles.stepLine, steps.indexOf(step) > index && styles.stepLineActive]} />}</View>)}</View>
    {step === "welcome" && <View style={styles.center}><View style={styles.heroIcon}><MaterialIcons name="home-work" size={48} color="#8B5E73" /></View><Text style={styles.heroTitle}>خلّي تجهيزك أهدى{"\n"}وأرتب</Text><Text style={styles.heroText}>جهازي يساعدك تعرفي إيه اللي عندك، وإيه اللي ناقص، وإيه اللي لازم تشتريه قبل الفرح.</Text><View style={styles.quote}><Text style={styles.quoteText}>«إيه اللي عندي؟ وإيه اللي ناقصني؟»</Text></View><PrimaryButton label="نبدأ سوا" onPress={openProfileStep} /></View>}
    {step === "profile" && <View><Text style={styles.kicker}>خطوة ١ من ٢</Text><Text style={styles.title}>نبدأ ببياناتك</Text><Text style={styles.subtitle}>عشان نرتب لكِ الأولويات على حسب وقتك.</Text><Field label="اسم العروسة" value={name} onChangeText={setName} placeholder="مثال: سارة" /><Field label="موعد الفرح" value={weddingDate} onChangeText={setWeddingDate} placeholder="2026-12-18" hint="استخدمي صيغة السنة-الشهر-اليوم" /><Text style={styles.label}>هل بدأتي تجهيز الجهاز؟</Text><ChoiceRow value={started} onChange={setStarted} options={[[true, "أيوه، بدأت"], [false, "لسه هبدأ"]]} /><PrimaryButton label="التالي" onPress={() => { if (!name.trim() || !isValidWeddingDate(weddingDate)) { Alert.alert("بيانات ناقصة", "اكتبي الاسم والتاريخ بشكل صحيح."); return; } setStep("setup"); }} /></View>}
    {step === "setup" && <View><Text style={styles.kicker}>خطوة ٢ من ٢</Text><Text style={styles.title}>نجهّز مساحتك</Text><Text style={styles.subtitle}>اختاري الطريقة اللي تريحك، وتقدري تعدّلي كل حاجة بعدين.</Text><Text style={styles.label}>تستخدمي القائمة الجاهزة؟</Text><ChoiceRow value={starterList} onChange={setStarterList} options={[[true, "أيوه، ابدئي بقائمة مقترحة"], [false, "لا، هضيف حاجتي بنفسي"]]} /><Text style={styles.label}>تحبي تحددي ميزانية؟</Text><ChoiceRow value={budgetEnabled} onChange={setBudgetEnabled} options={[[true, "أيوه"], [false, "لاحقًا"]]} />{budgetEnabled && <Field label="الميزانية التقريبية" value={budget} onChangeText={setBudget} placeholder="150000" keyboardType="number-pad" suffix="ج.م" />}<View style={styles.note}><MaterialIcons name="lightbulb-outline" size={19} color="#B7863F" /><Text style={styles.noteText}>{started === true ? "هنبدأ من اللي عندك ونرتب النواقص." : "هنجهز لك قائمة بسيطة تبدأي منها براحتك."}</Text></View><PrimaryButton label="ابدئي تجهيزك" onPress={finish} /></View>}
  </ScrollView></ScreenContainer>;
}

function PrimaryButton({ label, onPress }: { label: string; onPress: () => void }) { return <Pressable onPress={onPress} style={({ pressed }) => [styles.button, pressed && styles.pressed]}><Text style={styles.buttonText}>{label}</Text><MaterialIcons name="arrow-back" size={20} color="#FFF9F0" /></Pressable>; }
function Field({ label, value, onChangeText, placeholder, keyboardType, suffix, hint }: { label: string; value: string; onChangeText: (value: string) => void; placeholder: string; keyboardType?: any; suffix?: string; hint?: string }) { return <View style={styles.field}><View style={styles.labelRow}><Text style={styles.label}>{label}</Text>{hint ? <Text style={styles.hint}>{hint}</Text> : null}</View><View style={styles.inputWrap}><TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor="#B0A59D" keyboardType={keyboardType} style={styles.input} textAlign="right" returnKeyType="done" />{suffix ? <Text style={styles.suffix}>{suffix}</Text> : null}</View></View>; }
function ChoiceRow({ value, onChange, options }: { value: boolean | null; onChange: (value: boolean) => void; options: [boolean, string][] }) { return <View style={styles.choiceRow}>{options.map(([key, label]) => <Pressable key={label} onPress={() => onChange(key)} style={[styles.choice, value === key && styles.choiceActive]}><MaterialIcons name={value === key ? "radio-button-checked" : "radio-button-unchecked"} size={18} color={value === key ? "#8B5E73" : "#B5AAA2"} /><Text style={[styles.choiceText, value === key && styles.choiceTextActive]}>{label}</Text></Pressable>)}</View>; }

const styles = StyleSheet.create({ content: { flexGrow: 1, paddingTop: 22, paddingBottom: 34, writingDirection: "rtl" }, brand: { flexDirection: "row-reverse", alignItems: "center", gap: 8, alignSelf: "flex-end" }, brandMark: { width: 35, height: 35, borderRadius: 13, backgroundColor: "#F0E2C4", alignItems: "center", justifyContent: "center" }, brandText: { color: "#34283A", fontSize: 20, fontWeight: "800" }, stepper: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", marginTop: 28, marginBottom: 38 }, stepItem: { flexDirection: "row-reverse", alignItems: "center" }, stepDot: { width: 30, height: 30, borderRadius: 15, backgroundColor: "#F0EAE5", alignItems: "center", justifyContent: "center" }, stepDotActive: { backgroundColor: "#8B5E73" }, stepNumber: { color: "#A89B92", fontSize: 11, fontWeight: "800" }, stepNumberActive: { color: "#FFF9F0" }, stepLine: { width: 42, height: 2, backgroundColor: "#E9DED4" }, stepLineActive: { backgroundColor: "#D5A08A" }, center: { flex: 1, alignItems: "center", paddingTop: 15 }, heroIcon: { width: 96, height: 96, borderRadius: 34, backgroundColor: "#F2E5DC", alignItems: "center", justifyContent: "center", marginBottom: 24 }, heroTitle: { color: "#34283A", fontSize: 31, lineHeight: 41, fontWeight: "800", textAlign: "center" }, heroText: { color: "#867D76", fontSize: 14, lineHeight: 23, textAlign: "center", maxWidth: 315, marginTop: 14 }, quote: { backgroundColor: "#F4E9D8", borderRadius: 15, paddingHorizontal: 16, paddingVertical: 12, marginVertical: 24 }, quoteText: { color: "#77624B", fontSize: 12, fontWeight: "700" }, kicker: { color: "#8B5E73", fontSize: 13, fontWeight: "700", textAlign: "right" }, title: { color: "#34283A", fontSize: 28, lineHeight: 37, fontWeight: "800", marginTop: 4, textAlign: "right" }, subtitle: { color: "#867D76", fontSize: 13, lineHeight: 21, marginTop: 6, marginBottom: 24, textAlign: "right" }, field: { marginBottom: 17 }, labelRow: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 7 }, label: { color: "#5E514A", fontSize: 12, fontWeight: "800", textAlign: "right", marginBottom: 8 }, hint: { color: "#AA9D95", fontSize: 10 }, inputWrap: { minHeight: 50, flexDirection: "row-reverse", alignItems: "center", backgroundColor: "#FFFDFC", borderWidth: 1, borderColor: "#E9DED4", borderRadius: 15, paddingHorizontal: 13 }, input: { flex: 1, color: "#34283A", fontSize: 13, paddingVertical: 0 }, suffix: { color: "#8B5E73", fontSize: 12, fontWeight: "800", marginLeft: 7 }, choiceRow: { flexDirection: "row-reverse", gap: 8, marginBottom: 20 }, choice: { flex: 1, minHeight: 48, borderWidth: 1, borderColor: "#E9DED4", borderRadius: 14, backgroundColor: "#FFFDFC", flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 6, paddingHorizontal: 7 }, choiceActive: { backgroundColor: "#F2E5DC", borderColor: "#D5A08A" }, choiceText: { color: "#887D75", fontSize: 11, fontWeight: "700", textAlign: "center" }, choiceTextActive: { color: "#34283A" }, note: { flexDirection: "row-reverse", alignItems: "center", gap: 8, backgroundColor: "#F4E9D8", borderRadius: 15, padding: 13, marginBottom: 18 }, noteText: { flex: 1, color: "#77624B", fontSize: 11, lineHeight: 18, textAlign: "right" }, button: { height: 54, borderRadius: 17, backgroundColor: "#8B5E73", flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 13, shadowColor: "#8B5E73", shadowOpacity: 0.2, shadowRadius: 9, shadowOffset: { width: 0, height: 4 }, elevation: 3 }, buttonText: { color: "#FFF9F0", fontSize: 15, fontWeight: "800" }, pressed: { opacity: 0.7 },
});
