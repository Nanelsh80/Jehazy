import { describe, expect, it } from "vitest";
import { reminderDate } from "../lib/notifications";

describe("notification scheduling", () => {
  it("creates a reminder before the wedding", () => {
    const now = new Date("2026-10-01T10:00:00");
    const reminder = reminderDate("2026-11-01", 30, now);
    expect(reminder?.toISOString().slice(0, 10)).toBe("2026-10-02");
  });

  it("does not schedule reminders already in the past", () => {
    const now = new Date("2026-10-20T10:00:00");
    expect(reminderDate("2026-11-01", 30, now)).toBeNull();
  });
});
