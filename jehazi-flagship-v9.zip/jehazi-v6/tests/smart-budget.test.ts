import { describe, expect, it } from "vitest";
import { smartBudgetPlan } from "@/lib/inventory-context";

describe("smart budget plan", () => {
  it("calculates a weekly cap and prioritizes high priority purchases", () => {
    const items = [
      { id: "a", catalogId: "a", name: "ثلاجة", category: "device", subcategory: "أجهزة", room: "المطبخ", requiredQty: 1, ownedQty: 0, status: "toBuy", unitPrice: 20000, amountPaid: 0, priority: "high", store: "", brand: "", size: "", color: "", notes: "" },
      { id: "b", catalogId: "b", name: "شماعات", category: "small", subcategory: "تنظيم", room: "غرفة النوم", requiredQty: 10, ownedQty: 0, status: "toBuy", unitPrice: 50, amountPaid: 0, priority: "low", store: "", brand: "", size: "", color: "", notes: "" },
    ] as any;
    const result = smartBudgetPlan(items, { name: "سارة", weddingDate: "2027-01-01", budget: 30000 });
    expect(result.weeklyCap).toBeGreaterThan(0);
    expect(result.recommendedNow[0].name).toBe("ثلاجة");
  });
});
