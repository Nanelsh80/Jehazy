import { describe, expect, it } from "vitest";
import { smartShoppingList, warrantyItems } from "@/lib/inventory-context";

const base = (id: string, name: string, extra: any = {}) => ({
  id, catalogId: id, name, category: "device", subcategory: "أجهزة", room: "المطبخ", requiredQty: 1, ownedQty: 0, status: "toBuy", unitPrice: 1000, amountPaid: 0, priority: "medium", store: "", brand: "", size: "", color: "", notes: "", ...extra,
});

describe("flagship smart layers", () => {
  it("ranks high-priority shopping first", () => {
    const result = smartShoppingList([base("low", "منظم", { priority: "low" }), base("high", "غسالة", { priority: "high" })], { name: "سارة", weddingDate: "2027-01-01", budget: 5000 });
    expect(result[0].item.name).toBe("غسالة");
  });

  it("sorts warranty records by expiry", () => {
    const result = warrantyItems([base("late", "ثلاجة", { warrantyEndDate: "2028-01-01" }), base("soon", "غسالة", { warrantyEndDate: "2026-11-01" })]);
    expect(result[0].name).toBe("غسالة");
  });
});
