import { describe, expect, it } from "vitest";
import { budgetTotals, categoryBudget, categoryProgress, catalogToInventoryItem, daysUntilWedding, formatMoney, isValidWeddingDate, itemTotal, overallProgress, remainingQty, shoppingListItems, starterCatalog, subcategoryProgress, type InventoryItem } from "../lib/inventory-context";

const base = (patch: Partial<InventoryItem> = {}): InventoryItem => ({
  id: "test",
  name: "قطعة",
  category: "device",
  subcategory: "اختبار",
  room: "المطبخ",
  requiredQty: 4,
  ownedQty: 1,
  status: "toBuy",
  unitPrice: 100,
  amountPaid: 0,
  priority: "medium",
  store: "",
  brand: "",
  size: "",
  color: "",
  notes: "",
  ...patch,
});

describe("inventory calculations", () => {
  it("calculates remaining quantity without going below zero", () => {
    expect(remainingQty(base())).toBe(3);
    expect(remainingQty(base({ ownedQty: 8 }))).toBe(0);
  });

  it("calculates item total from required quantity and unit price", () => {
    expect(itemTotal(base({ requiredQty: 6, unitPrice: 275 }))).toBe(1650);
  });

  it("calculates category progress and excludes not-needed items", () => {
    const items = [
      base({ id: "a", requiredQty: 4, ownedQty: 2 }),
      base({ id: "b", requiredQty: 2, ownedQty: 2 }),
      base({ id: "c", requiredQty: 10, ownedQty: 0, status: "notNeeded" }),
    ];
    expect(categoryProgress(items, "device")).toBe(67);
  });

  it("formats Egyptian currency in Arabic locale", () => {
    expect(formatMoney(12500)).toContain("١٢٬٥٠٠");
    expect(formatMoney(12500)).toContain("ج.م");
  });

  it("returns zero for a wedding date that has already passed", () => {
    expect(daysUntilWedding("2020-01-01")).toBe(0);
  });

  it("validates the onboarding wedding date format", () => {
    expect(isValidWeddingDate("2026-12-18")).toBe(true);
    expect(isValidWeddingDate("18-12-2026")).toBe(false);
    expect(isValidWeddingDate("2026-99-99")).toBe(false);
  });

  it("provides structured starter catalog metadata and converts it to inventory", () => {
    expect(starterCatalog).toHaveLength(13);
    expect(starterCatalog.find((entry) => entry.name === "ملايات استك")).toMatchObject({ suggestedQty: 6, unit: "طقم", required: true });
    expect(catalogToInventoryItem(starterCatalog[0])).toMatchObject({ catalogId: starterCatalog[0].id, requiredQty: starterCatalog[0].suggestedQty, unitPrice: starterCatalog[0].defaultUnitPrice });
  });

  it("derives and clears shopping-list quantities from owned quantity", () => {
    const item = base({ id: "sheets", name: "ملايات استك", requiredQty: 6, ownedQty: 4 });
    expect(shoppingListItems([item])).toHaveLength(1);
    expect(remainingQty(item)).toBe(2);
    const complete = { ...item, ownedQty: 6 };
    expect(remainingQty(complete)).toBe(0);
    expect(shoppingListItems([complete])).toHaveLength(0);
    expect(shoppingListItems([{ ...item, status: "notNeeded" }])).toHaveLength(0);
  });

  it("calculates overall and subcategory progress while excluding not-needed items", () => {
    const items = [
      base({ id: "a", category: "bedding", subcategory: "الملايات", requiredQty: 6, ownedQty: 4 }),
      base({ id: "b", category: "bedding", subcategory: "الملايات", requiredQty: 2, ownedQty: 2 }),
      base({ id: "c", category: "device", requiredQty: 10, ownedQty: 0, status: "notNeeded" }),
    ];
    expect(subcategoryProgress(items, "bedding", "الملايات")).toBe(75);
    expect(overallProgress(items)).toBe(75);
  });

  it("aggregates item budgets by category and across active inventory", () => {
    const items = [
      base({ id: "a", category: "device", requiredQty: 6, unitPrice: 275, amountPaid: 500 }),
      base({ id: "b", category: "clothes", requiredQty: 2, unitPrice: 100, amountPaid: 50 }),
      base({ id: "c", category: "device", requiredQty: 1, unitPrice: 1000, amountPaid: 1000, status: "notNeeded" }),
    ];
    expect(categoryBudget(items, "device")).toEqual({ estimated: 1650, paid: 500, remaining: 1150 });
    expect(budgetTotals(items)).toEqual({ estimated: 1850, paid: 550, remaining: 1300 });
  });
});
