import { describe, expect, it } from "vitest";
import { onboardingStepFromParam, shouldUseStarterList } from "../lib/onboarding";

describe("onboarding startup routing", () => {
  it("opens the profile step for the explicit profile route parameter", () => {
    expect(onboardingStepFromParam("profile")).toBe("profile");
  });

  it("opens setup for the explicit setup route parameter", () => {
    expect(onboardingStepFromParam("setup")).toBe("setup");
  });

  it("opens the usable profile form for missing or invalid parameters", () => {
    expect(onboardingStepFromParam(undefined)).toBe("profile");
    expect(onboardingStepFromParam("unknown")).toBe("profile");
    expect(onboardingStepFromParam(["profile", "extra"])).toBe("profile");
  });

  it("keeps the welcome screen available only when explicitly requested", () => {
    expect(onboardingStepFromParam("welcome")).toBe("welcome");
  });

  it("only enables the starter list after an explicit yes", () => {
    expect(shouldUseStarterList(true)).toBe(true);
    expect(shouldUseStarterList(false)).toBe(false);
    expect(shouldUseStarterList(null)).toBe(false);
  });
});
