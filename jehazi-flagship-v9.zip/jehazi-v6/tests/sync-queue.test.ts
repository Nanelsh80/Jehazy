import { beforeEach, describe, expect, it } from "vitest";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { clearSyncQueue, hasPendingSync, queueSnapshot, readSyncQueue } from "@/lib/sync-queue";

const snapshot = { profile: { name: "سارة", weddingDate: "2027-06-10", budget: 100000 }, items: [] };

describe("sync queue", () => {
  beforeEach(async () => {
    await AsyncStorage.clear();
  });

  it("persists a pending snapshot across reads", async () => {
    expect(await hasPendingSync()).toBe(false);
    await queueSnapshot(snapshot, new Error("offline"));
    const queued = await readSyncQueue();
    expect(queued?.snapshot.profile.name).toBe("سارة");
    expect(queued?.lastError).toBe("offline");
    expect(await hasPendingSync()).toBe(true);
  });

  it("clears the queue after a successful sync", async () => {
    await queueSnapshot(snapshot);
    await clearSyncQueue();
    expect(await readSyncQueue()).toBeNull();
  });
});
