ALTER TABLE `users` ADD COLUMN `passwordHash` text NULL;
ALTER TABLE `users` MODIFY COLUMN `openId` varchar(128) NOT NULL;
ALTER TABLE `inventory_items` ADD COLUMN `warrantyUri` text NULL;
ALTER TABLE `inventory_items` ADD COLUMN `warrantyName` varchar(255) NULL;
ALTER TABLE `inventory_items` ADD COLUMN `warrantyStartDate` varchar(10) NULL;
ALTER TABLE `inventory_items` ADD COLUMN `warrantyEndDate` varchar(10) NULL;
ALTER TABLE `inventory_items` ADD COLUMN `warrantyProvider` varchar(160) NULL;
ALTER TABLE `inventory_items` ADD COLUMN `warrantyNotes` text NULL;
ALTER TABLE `users` ADD UNIQUE INDEX `users_email_unique` (`email`);
