import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, uniqueIndex } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Unique authentication identifier for the user. */
  openId: varchar("openId", { length: 128 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  passwordHash: text("passwordHash"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
}, (table) => ({
  emailIdx: uniqueIndex("users_email_unique").on(table.email),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;


export const brideProfiles = mysqlTable("bride_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  name: varchar("name", { length: 160 }).notNull().default(""),
  weddingDate: varchar("weddingDate", { length: 10 }).notNull().default(""),
  budget: decimal("budget", { precision: 14, scale: 2 }).notNull().default("0"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const inventoryItems = mysqlTable("inventory_items", {
  id: varchar("id", { length: 80 }).primaryKey(),
  userId: int("userId").notNull(),
  catalogId: varchar("catalogId", { length: 80 }),
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 40 }).notNull(),
  subcategory: varchar("subcategory", { length: 120 }).notNull(),
  room: varchar("room", { length: 120 }).notNull(),
  requiredQty: int("requiredQty").notNull().default(0),
  ownedQty: int("ownedQty").notNull().default(0),
  status: varchar("status", { length: 40 }).notNull(),
  unitPrice: decimal("unitPrice", { precision: 14, scale: 2 }).notNull().default("0"),
  amountPaid: decimal("amountPaid", { precision: 14, scale: 2 }).notNull().default("0"),
  priority: varchar("priority", { length: 20 }).notNull(),
  store: varchar("store", { length: 160 }).notNull().default(""),
  brand: varchar("brand", { length: 160 }).notNull().default(""),
  size: varchar("size", { length: 100 }).notNull().default(""),
  color: varchar("color", { length: 100 }).notNull().default(""),
  notes: text("notes").notNull(),
  purchaseDate: varchar("purchaseDate", { length: 10 }),
  deliveryDate: varchar("deliveryDate", { length: 10 }),
  photoUri: text("photoUri"),
  receiptUri: text("receiptUri"),
  receiptName: varchar("receiptName", { length: 255 }),
  warrantyUri: text("warrantyUri"),
  warrantyName: varchar("warrantyName", { length: 255 }),
  warrantyStartDate: varchar("warrantyStartDate", { length: 10 }),
  warrantyEndDate: varchar("warrantyEndDate", { length: 10 }),
  warrantyProvider: varchar("warrantyProvider", { length: 160 }),
  warrantyNotes: text("warrantyNotes"),
  photoAssetId: varchar("photoAssetId", { length: 80 }),
  receiptAssetId: varchar("receiptAssetId", { length: 80 }),
  warrantyAssetId: varchar("warrantyAssetId", { length: 80 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userUpdatedIdx: uniqueIndex("inventory_user_id_item_id_idx").on(table.userId, table.id),
}));

export type BrideProfile = typeof brideProfiles.$inferSelect;
export type InsertBrideProfile = typeof brideProfiles.$inferInsert;
export type InventoryItemRow = typeof inventoryItems.$inferSelect;
export type InsertInventoryItemRow = typeof inventoryItems.$inferInsert;



export const jehaziAssets = mysqlTable("jehazi_assets", {
  id: varchar("id", { length: 80 }).primaryKey(),
  userId: int("userId").notNull(),
  itemId: varchar("itemId", { length: 80 }).notNull(),
  kind: mysqlEnum("kind", ["photo", "receipt", "warranty"]).notNull(),
  objectKey: varchar("objectKey", { length: 700 }).notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  contentType: varchar("contentType", { length: 160 }).notNull(),
  byteSize: int("byteSize").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userItemKindIdx: uniqueIndex("jehazi_assets_user_item_kind_idx").on(table.userId, table.itemId, table.kind),
}));

export type JeHaziAsset = typeof jehaziAssets.$inferSelect;
export type InsertJeHaziAsset = typeof jehaziAssets.$inferInsert;
