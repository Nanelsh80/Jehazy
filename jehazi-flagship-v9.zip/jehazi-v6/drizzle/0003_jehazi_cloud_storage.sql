ALTER TABLE `inventory_items` ADD COLUMN `photoAssetId` varchar(80) NULL;
ALTER TABLE `inventory_items` ADD COLUMN `receiptAssetId` varchar(80) NULL;
ALTER TABLE `inventory_items` ADD COLUMN `warrantyAssetId` varchar(80) NULL;
CREATE TABLE `jehazi_assets` (
  `id` varchar(80) NOT NULL,
  `userId` int NOT NULL,
  `itemId` varchar(80) NOT NULL,
  `kind` enum('photo','receipt','warranty') NOT NULL,
  `objectKey` varchar(700) NOT NULL,
  `fileName` varchar(255) NOT NULL,
  `contentType` varchar(160) NOT NULL,
  `byteSize` int NOT NULL DEFAULT 0,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `jehazi_assets_user_item_kind_idx` (`userId`,`itemId`,`kind`)
);
