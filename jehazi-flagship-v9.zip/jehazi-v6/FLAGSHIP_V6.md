# JEHAZI Flagship v6

## Product direction
JEHAZI is positioned as a premium Arabic RTL **Bride Command Center**, not a simple checklist.

## v6 additions
- Smart Shopping ranking based on priority, status, wedding deadline, and estimated cost.
- Warranty Center with active / expiring-soon / expired states.
- Warranty start/end dates and provider fields on every item.
- Warranty-card document attachment alongside receipts and product photos.
- Warranty records sorted by expiry for proactive follow-up.
- Purchases screen now surfaces the smartest first purchase instead of a flat list.
- Brand/icon system from v5 retained: deep plum, champagne gold, ivory, quiet-luxury editorial direction.
- Deep-link identity remains `jehazi` with package/bundle ID `com.jehazi.app`.

## Data compatibility
Warranty metadata is stored inside each inventory item and therefore remains compatible with the existing snapshot-based cloud sync without a destructive migration.

## Vendor independence note
The JEHAZI UI and domain layer no longer derive their identity/deep-link scheme from the original template vendor. The repository still contains legacy backend authentication/storage adapter files inherited from the starter template; these are isolated behind the API boundary and should be replaced with JEHAZI-owned authentication/storage infrastructure before public production launch.

## QA note
This environment did not contain `pnpm`/`node_modules`, and package installation could not be performed because registry access was unavailable. No claim of a successful TypeScript/Vitest run is made for this archive.
