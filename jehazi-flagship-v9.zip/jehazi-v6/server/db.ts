import { and, eq } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, brideProfiles, inventoryItems, jehaziAssets } from "../drizzle/schema";
import { ENV } from "./_core/env";
import { createReadUrl, storageConfigured, type AssetKind } from "./_core/storage";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.passwordHash !== undefined) {
      values.passwordHash = user.passwordHash ?? null;
      updateSet.passwordHash = user.passwordHash ?? null;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.email && ENV.ownerEmail && user.email.toLowerCase() === ENV.ownerEmail.toLowerCase()) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// TODO: add feature queries here as your schema grows.

export async function getJeHaziSnapshot(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const [profileRows, itemRows, assetRows] = await Promise.all([
    db.select().from(brideProfiles).where(eq(brideProfiles.userId, userId)).limit(1),
    db.select().from(inventoryItems).where(eq(inventoryItems.userId, userId)),
    db.select().from(jehaziAssets).where(eq(jehaziAssets.userId, userId)),
  ]);
  const assetUrlById = new Map(assetRows.map((asset) => [asset.id, storageConfigured() ? createReadUrl(asset.objectKey)?.signedUrl : undefined]));
  return {
    profile: profileRows[0] ? {
      name: profileRows[0].name,
      weddingDate: profileRows[0].weddingDate,
      budget: Number(profileRows[0].budget ?? 0),
    } : null,
    items: itemRows.map((row) => ({
      id: row.id, catalogId: row.catalogId ?? undefined, name: row.name, category: row.category, subcategory: row.subcategory, room: row.room,
      requiredQty: row.requiredQty, ownedQty: row.ownedQty, status: row.status, unitPrice: Number(row.unitPrice ?? 0), amountPaid: Number(row.amountPaid ?? 0),
      priority: row.priority, store: row.store, brand: row.brand, size: row.size, color: row.color, notes: row.notes, purchaseDate: row.purchaseDate ?? undefined, deliveryDate: row.deliveryDate ?? undefined,
      photoUri: assetUrlById.get(row.photoAssetId ?? "") ?? row.photoUri ?? undefined,
      receiptUri: assetUrlById.get(row.receiptAssetId ?? "") ?? row.receiptUri ?? undefined, receiptName: row.receiptName ?? undefined,
      warrantyUri: assetUrlById.get(row.warrantyAssetId ?? "") ?? row.warrantyUri ?? undefined, warrantyName: row.warrantyName ?? undefined,
      warrantyStartDate: row.warrantyStartDate ?? undefined, warrantyEndDate: row.warrantyEndDate ?? undefined, warrantyProvider: row.warrantyProvider ?? undefined, warrantyNotes: row.warrantyNotes ?? undefined,
      photoAssetId: row.photoAssetId ?? undefined, receiptAssetId: row.receiptAssetId ?? undefined, warrantyAssetId: row.warrantyAssetId ?? undefined,
    })),
  };
}

export async function createJeHaziAsset(userId: number, input: { itemId: string; kind: AssetKind; fileName: string; contentType: string; byteSize: number; objectKey: string; }) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const item = await db.select({ id: inventoryItems.id }).from(inventoryItems).where(and(eq(inventoryItems.id, input.itemId), eq(inventoryItems.userId, userId))).limit(1);
  if (!item[0]) throw new Error("Inventory item not found");
  const existing = await db.select().from(jehaziAssets).where(and(eq(jehaziAssets.userId, userId), eq(jehaziAssets.itemId, input.itemId), eq(jehaziAssets.kind, input.kind))).limit(1);
  if (existing[0]) await db.delete(jehaziAssets).where(and(eq(jehaziAssets.id, existing[0].id), eq(jehaziAssets.userId, userId)));
  const assetId = `asset-${randomUUID()}`;
  await db.insert(jehaziAssets).values({ id: assetId, userId, itemId: input.itemId, kind: input.kind, objectKey: input.objectKey, fileName: input.fileName, contentType: input.contentType, byteSize: input.byteSize });
  const field = input.kind === "photo" ? "photoAssetId" : input.kind === "receipt" ? "receiptAssetId" : "warrantyAssetId";
  const uriField = input.kind === "photo" ? "photoUri" : input.kind === "receipt" ? "receiptUri" : "warrantyUri";
  const nameField = input.kind === "receipt" ? "receiptName" : "warrantyName";
  const patch: Record<string, unknown> = { [field]: assetId, [uriField]: null };
  if (nameField) patch[nameField] = input.fileName;
  await db.update(inventoryItems).set(patch).where(and(eq(inventoryItems.id, input.itemId), eq(inventoryItems.userId, userId)));
  return { id: assetId, itemId: input.itemId, kind: input.kind, fileName: input.fileName, contentType: input.contentType, objectKey: input.objectKey };
}

export async function deleteJeHaziAsset(userId: number, assetId: string) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const asset = await db.select().from(jehaziAssets).where(and(eq(jehaziAssets.id, assetId), eq(jehaziAssets.userId, userId))).limit(1);
  if (!asset[0]) return false;
  const field = asset[0].kind === "photo" ? "photoAssetId" : asset[0].kind === "receipt" ? "receiptAssetId" : "warrantyAssetId";
  const uriField = asset[0].kind === "photo" ? "photoUri" : asset[0].kind === "receipt" ? "receiptUri" : "warrantyUri";
  await db.update(inventoryItems).set({ [field]: null, [uriField]: null }).where(and(eq(inventoryItems.id, asset[0].itemId), eq(inventoryItems.userId, userId)));
  await db.delete(jehaziAssets).where(and(eq(jehaziAssets.id, assetId), eq(jehaziAssets.userId, userId)));
  return true;
}

export async function saveJeHaziSnapshot(userId: number, snapshot: {
  profile: { name: string; weddingDate: string; budget: number }; items: Array<Record<string, any>>;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.insert(brideProfiles).values({ userId, name: snapshot.profile.name ?? "", weddingDate: snapshot.profile.weddingDate ?? "", budget: String(snapshot.profile.budget ?? 0) }).onDuplicateKeyUpdate({ set: { name: snapshot.profile.name ?? "", weddingDate: snapshot.profile.weddingDate ?? "", budget: String(snapshot.profile.budget ?? 0) } });
  const existing = await db.select({ id: inventoryItems.id }).from(inventoryItems).where(eq(inventoryItems.userId, userId));
  const incomingIds = new Set(snapshot.items.map((item) => String(item.id)));
  for (const item of snapshot.items) {
    const itemId = String(item.id);
    const collision = await db.select({ userId: inventoryItems.userId }).from(inventoryItems).where(eq(inventoryItems.id, itemId)).limit(1);
    if (collision[0] && collision[0].userId !== userId) throw new Error("Inventory item ownership conflict");
    const values = { id: itemId, userId, catalogId: item.catalogId ?? null, name: String(item.name ?? ""), category: String(item.category ?? "small"), subcategory: String(item.subcategory ?? ""), room: String(item.room ?? ""), requiredQty: Number(item.requiredQty ?? 0), ownedQty: Number(item.ownedQty ?? 0), status: String(item.status ?? "undecided"), unitPrice: String(Number(item.unitPrice ?? 0)), amountPaid: String(Number(item.amountPaid ?? 0)), priority: String(item.priority ?? "medium"), store: String(item.store ?? ""), brand: String(item.brand ?? ""), size: String(item.size ?? ""), color: String(item.color ?? ""), notes: String(item.notes ?? ""), purchaseDate: item.purchaseDate ?? null, deliveryDate: item.deliveryDate ?? null, photoUri: item.photoUri?.startsWith?.("file://") ? item.photoUri : (item.photoUri ?? null), receiptUri: item.receiptUri?.startsWith?.("file://") ? item.receiptUri : (item.receiptUri ?? null), receiptName: item.receiptName ?? null, warrantyUri: item.warrantyUri?.startsWith?.("file://") ? item.warrantyUri : (item.warrantyUri ?? null), warrantyName: item.warrantyName ?? null, warrantyStartDate: item.warrantyStartDate ?? null, warrantyEndDate: item.warrantyEndDate ?? null, warrantyProvider: item.warrantyProvider ?? null, warrantyNotes: item.warrantyNotes ?? null, photoAssetId: item.photoAssetId ?? null, receiptAssetId: item.receiptAssetId ?? null, warrantyAssetId: item.warrantyAssetId ?? null };
    await db.insert(inventoryItems).values(values).onDuplicateKeyUpdate({ set: { ...values, userId } });
  }
  for (const row of existing) if (!incomingIds.has(row.id)) await db.delete(inventoryItems).where(and(eq(inventoryItems.id, row.id), eq(inventoryItems.userId, userId)));
  return getJeHaziSnapshot(userId);
}
