import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { getJeHaziSnapshot, saveJeHaziSnapshot } from "./db";
import { z } from "zod";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user ? ({ id: opts.ctx.user.id, openId: opts.ctx.user.openId, name: opts.ctx.user.name, email: opts.ctx.user.email, loginMethod: opts.ctx.user.loginMethod, role: opts.ctx.user.role, lastSignedIn: opts.ctx.user.lastSignedIn }) : null),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  jehazi: router({
    snapshot: protectedProcedure.query(({ ctx }) => getJeHaziSnapshot(ctx.user.id)),
    saveSnapshot: protectedProcedure.input(z.object({
      profile: z.object({ name: z.string(), weddingDate: z.string(), budget: z.number() }),
      items: z.array(z.record(z.string(), z.any())),
    })).mutation(({ ctx, input }) => saveJeHaziSnapshot(ctx.user.id, input)),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
