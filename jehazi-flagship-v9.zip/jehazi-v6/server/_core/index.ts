import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerLocalAuthRoutes } from "./local-auth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { sdk } from "./sdk";
import { createJeHaziAsset, deleteJeHaziAsset, getJeHaziSnapshot, saveJeHaziSnapshot } from "../db";
import { createAssetKey, createReadUrl, createUploadUrl, storageConfigured, type AssetKind } from "./storage";
import { ENV } from "./env";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Enable CORS for all routes - reflect the request origin to support credentials
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin && (ENV.allowedOrigins.length === 0 ? !ENV.isProduction : ENV.allowedOrigins.includes(origin))) {
      res.header("Access-Control-Allow-Origin", origin);
      res.header("Vary", "Origin");
    }
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization",
    );
    res.header("Access-Control-Allow-Credentials", "true");

    // Handle preflight requests
    if (req.method === "OPTIONS") {
      res.sendStatus(200);
      return;
    }
    next();
  });

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  registerLocalAuthRoutes(app);

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, timestamp: Date.now() });
  });

  app.get("/api/jehazi/snapshot", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (!user) return res.status(401).json({ error: "Unauthorized" });
      const snapshot = await getJeHaziSnapshot(user.id);
      return res.json(snapshot);
    } catch (error) {
      console.error("[JeHazi] Snapshot GET failed:", error);
      return res.status(500).json({ error: "Failed to load JeHazi data" });
    }
  });

  app.post("/api/jehazi/assets/presign", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (!user) return res.status(401).json({ error: "Unauthorized" });
      if (!storageConfigured()) return res.status(503).json({ error: "Cloud storage is not configured yet" });
      const itemId = String(req.body?.itemId ?? "");
      const kind = String(req.body?.kind ?? "") as AssetKind;
      const fileName = String(req.body?.fileName ?? "file");
      const contentType = String(req.body?.contentType ?? "application/octet-stream");
      const byteSize = Math.max(0, Number(req.body?.byteSize ?? 0));
      if (!itemId || !["photo", "receipt", "warranty"].includes(kind) || !fileName) return res.status(400).json({ error: "Invalid asset metadata" });
      const objectKey = createAssetKey(user.id, itemId, kind, fileName);
      const upload = createUploadUrl(objectKey, contentType);
      if (!upload) return res.status(503).json({ error: "Cloud storage is not configured yet" });
      const asset = await createJeHaziAsset(user.id, { itemId, kind, fileName, contentType, byteSize, objectKey });
      const read = createReadUrl(objectKey);
      return res.status(201).json({ ...asset, uploadUrl: upload.signedUrl, readUrl: read?.signedUrl ?? null });
    } catch (error) {
      console.error("[JeHazi] Asset presign failed:", error);
      return res.status(500).json({ error: "Failed to prepare cloud upload" });
    }
  });

  app.delete("/api/jehazi/assets/:assetId", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (!user) return res.status(401).json({ error: "Unauthorized" });
      const deleted = await deleteJeHaziAsset(user.id, String(req.params.assetId));
      return res.json({ success: deleted });
    } catch (error) {
      console.error("[JeHazi] Asset delete failed:", error);
      return res.status(500).json({ error: "Failed to delete cloud asset" });
    }
  });

  app.put("/api/jehazi/snapshot", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (!user) return res.status(401).json({ error: "Unauthorized" });
      const body = req.body;
      if (!body?.profile || !Array.isArray(body.items)) {
        return res.status(400).json({ error: "Invalid snapshot" });
      }
      const snapshot = await saveJeHaziSnapshot(user.id, body);
      return res.json(snapshot);
    } catch (error) {
      console.error("[JeHazi] Snapshot PUT failed:", error);
      return res.status(500).json({ error: "Failed to save JeHazi data" });
    }
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    }),
  );

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`[api] server listening on port ${port}`);
  });
}

startServer().catch(console.error);
