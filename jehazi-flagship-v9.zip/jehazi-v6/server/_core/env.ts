export const ENV = {
  databaseUrl: process.env.DATABASE_URL ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  ownerEmail: process.env.OWNER_EMAIL ?? "",
  isProduction: process.env.NODE_ENV === "production",
  storageEndpoint: process.env.STORAGE_ENDPOINT ?? "",
  storageBucket: process.env.STORAGE_BUCKET ?? "",
  storageRegion: process.env.STORAGE_REGION ?? "auto",
  storageAccessKey: process.env.STORAGE_ACCESS_KEY ?? "",
  storageSecretKey: process.env.STORAGE_SECRET_KEY ?? "",
  allowedOrigins: (process.env.ALLOWED_ORIGINS ?? "").split(",").map((value) => value.trim()).filter(Boolean),
};
