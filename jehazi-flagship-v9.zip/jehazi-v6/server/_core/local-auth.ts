import type { Express, Request, Response } from "express";
import { randomUUID, scryptSync, timingSafeEqual } from "node:crypto";
import { COOKIE_NAME, ONE_YEAR_MS } from "../../shared/const.js";
import { getUserByEmail, getUserByOpenId, upsertUser } from "../db";
import { getSessionCookieOptions } from "./cookies";
import { sdk } from "./sdk";

const normalizeEmail = (value: unknown) => String(value ?? "").trim().toLowerCase();
const hashPassword = (password: string) => {
  const salt = randomUUID().replaceAll("-", "");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `scrypt$${salt}$${hash}`;
};
const verifyPassword = (password: string, stored: string) => {
  const [algorithm, salt, hash] = stored.split("$");
  if (algorithm !== "scrypt" || !salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return expected.length === candidate.length && timingSafeEqual(expected, candidate);
};

function buildUserResponse(user: any) {
  return {
    id: user?.id ?? null,
    openId: user?.openId ?? null,
    name: user?.name ?? null,
    email: user?.email ?? null,
    loginMethod: user?.loginMethod ?? null,
    lastSignedIn: (user?.lastSignedIn ?? new Date()).toISOString(),
  };
}

function setSession(res: Response, req: Request, token: string) {
  const cookieOptions = getSessionCookieOptions(req);
  res.cookie(COOKIE_NAME, token, { ...cookieOptions, maxAge: ONE_YEAR_MS });
}

export function registerLocalAuthRoutes(app: Express) {
  app.post("/api/auth/register", async (req, res) => {
    try {
      const name = String(req.body?.name ?? "").trim();
      const email = normalizeEmail(req.body?.email);
      const password = String(req.body?.password ?? "");
      if (name.length < 2) return res.status(400).json({ error: "اكتبي اسمك بشكل صحيح" });
      if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: "البريد الإلكتروني غير صحيح" });
      if (password.length < 8) return res.status(400).json({ error: "كلمة المرور يجب أن تكون 8 أحرف على الأقل" });
      if (await getUserByEmail(email)) return res.status(409).json({ error: "هذا البريد مسجل بالفعل" });

      const openId = `local:${randomUUID()}`;
      await upsertUser({ openId, name, email, loginMethod: "email", passwordHash: hashPassword(password), lastSignedIn: new Date() });
      const user = await getUserByOpenId(openId);
      if (!user) return res.status(500).json({ error: "تعذر إنشاء الحساب" });
      const token = await sdk.createSessionToken(openId, { name });
      setSession(res, req, token);
      return res.status(201).json({ sessionToken: token, user: buildUserResponse(user) });
    } catch (error) {
      console.error("[Auth] Register failed", error);
      return res.status(500).json({ error: "تعذر إنشاء الحساب الآن" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const email = normalizeEmail(req.body?.email);
      const password = String(req.body?.password ?? "");
      const user = await getUserByEmail(email);
      if (!user || !user.passwordHash || !verifyPassword(password, user.passwordHash)) {
        return res.status(401).json({ error: "البريد الإلكتروني أو كلمة المرور غير صحيحة" });
      }
      await upsertUser({ openId: user.openId, lastSignedIn: new Date() });
      const fresh = (await getUserByOpenId(user.openId)) ?? user;
      const token = await sdk.createSessionToken(fresh.openId, { name: fresh.name ?? "" });
      setSession(res, req, token);
      return res.json({ sessionToken: token, user: buildUserResponse(fresh) });
    } catch (error) {
      console.error("[Auth] Login failed", error);
      return res.status(500).json({ error: "تعذر تسجيل الدخول الآن" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    const cookieOptions = getSessionCookieOptions(req);
    res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    res.json({ success: true });
  });

  app.get("/api/auth/me", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      res.json({ user: buildUserResponse(user) });
    } catch {
      res.status(401).json({ error: "Not authenticated", user: null });
    }
  });

  app.post("/api/auth/session", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      const authHeader = req.headers.authorization || req.headers.Authorization;
      if (typeof authHeader !== "string" || !authHeader.startsWith("Bearer ")) return res.status(400).json({ error: "Bearer token required" });
      const token = authHeader.slice("Bearer ".length).trim();
      setSession(res, req, token);
      res.json({ success: true, user: buildUserResponse(user) });
    } catch {
      res.status(401).json({ error: "Invalid token" });
    }
  });
}
