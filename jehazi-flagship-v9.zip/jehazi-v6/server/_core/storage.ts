import { createHash, createHmac, randomUUID } from "node:crypto";
import { ENV } from "./env";

export type AssetKind = "photo" | "receipt" | "warranty";

const encodePath = (value: string) => value.split("/").map(encodeURIComponent).join("/");
function hmac(key: Buffer | string, value: string) {
  return createHmac("sha256", key).update(value).digest();
}

function awsHash(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

export function storageConfigured() {
  return Boolean(ENV.storageEndpoint && ENV.storageBucket && ENV.storageAccessKey && ENV.storageSecretKey);
}

function endpoint() {
  return ENV.storageEndpoint.replace(/\/$/, "");
}

function hostAndBase() {
  const url = new URL(endpoint());
  return { url, host: url.host };
}

function signingKey(secret: string, date: string, region: string) {
  const kDate = hmac(`AWS4${secret}`, date);
  const kRegion = hmac(kDate, region);
  const kService = hmac(kRegion, "s3");
  return hmac(kService, "aws4_request");
}

function presign(method: "GET" | "PUT", key: string, contentType: string | undefined, expiresSeconds: number) {
  if (!storageConfigured()) return null;
  const { url, host } = hostAndBase();
  const now = new Date();
  const amzDate = now.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
  const shortDate = amzDate.slice(0, 8);
  const region = ENV.storageRegion;
  const credential = `${ENV.storageAccessKey}/${shortDate}/${region}/s3/aws4_request`;
  const objectPath = `${url.pathname.replace(/\/$/, "")}/${ENV.storageBucket}/${encodePath(key)}`;
  const query = new URLSearchParams({
    "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
    "X-Amz-Credential": credential,
    "X-Amz-Date": amzDate,
    "X-Amz-Expires": String(expiresSeconds),
    "X-Amz-SignedHeaders": "host",
  });
  const canonicalQuery = [...query.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([k,v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&");
  const canonicalHeaders = `host:${host}\n`;
  const signedHeaders = "host";
  const payloadHash = "UNSIGNED-PAYLOAD";
  const canonicalRequest = [method, objectPath || "/", canonicalQuery, canonicalHeaders, signedHeaders, payloadHash].join("\n");
  const scope = `${shortDate}/${region}/s3/aws4_request`;
  const stringToSign = `AWS4-HMAC-SHA256\n${amzDate}\n${scope}\n${awsHash(canonicalRequest)}`;
  const signature = hmac(signingKey(ENV.storageSecretKey, shortDate, region), stringToSign).toString("hex");
  query.set("X-Amz-Signature", signature);
  const publicUrl = `${endpoint()}${url.pathname.replace(/\/$/, "")}/${ENV.storageBucket}/${encodePath(key)}`;
  const signedUrl = `${endpoint()}${url.pathname.replace(/\/$/, "")}/${ENV.storageBucket}/${encodePath(key)}?${query.toString()}`;
  return { signedUrl, publicUrl };
}

export function createAssetKey(userId: number, itemId: string, kind: AssetKind, fileName: string) {
  const safe = fileName.replace(/[^a-zA-Z0-9._-]+/g, "-").slice(-120) || "file";
  return `users/${userId}/items/${itemId}/${kind}/${randomUUID()}-${safe}`;
}

export function createUploadUrl(key: string, contentType: string) {
  return presign("PUT", key, contentType, 900);
}

export function createReadUrl(key: string) {
  return presign("GET", key, undefined, 3600);
}
