# JEHAZI Flagship v9 — Production Release Gate

## What changed

- Offline-first cloud synchronization queue stored in AsyncStorage.
- Automatic retry when the app returns to foreground and every 30 seconds while active.
- Pending sync indicator and manual retry action on the Bride Command Center.
- Session-expiry handling: API 401 responses clear the native session and return the user to authentication.
- Bride Command Center dashboard with four operational KPIs: items to buy, orders to follow, high-priority gaps, and available budget.
- Existing cloud storage, warranty center, notifications, and flagship visual identity remain intact.

## Sync behavior

1. Local state is always written to device storage first.
2. Cloud writes are debounced.
3. Failed writes are stored as a full pending snapshot.
4. The queue survives app restarts.
5. Retry occurs on foreground and periodically.
6. A successful write clears the queue.

This intentionally favors local data safety over aggressive cloud writes. A future multi-device collaboration phase should add a server-side revision/merge protocol before enabling concurrent editing across devices.

## Release status

- Runtime TypeScript syntax: to be verified in a dependency-complete environment.
- Expo Android AAB: requires EAS credentials and a network-enabled build environment.
- Storage credentials: supplied through environment variables only.
