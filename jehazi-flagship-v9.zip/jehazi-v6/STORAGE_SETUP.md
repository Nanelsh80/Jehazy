# JEHAZI Flagship v9 — Cloud Storage

JEHAZI remains independent from Manus. File storage uses an S3-compatible provider (AWS S3, Cloudflare R2, MinIO, or another compatible service).

## Server environment

Set these variables on the API server:

- `STORAGE_ENDPOINT` — e.g. `https://<account>.r2.cloudflarestorage.com`
- `STORAGE_BUCKET` — bucket name
- `STORAGE_REGION` — `auto` for Cloudflare R2, or the provider region
- `STORAGE_ACCESS_KEY`
- `STORAGE_SECRET_KEY`

The app does not receive these secrets. The server creates short-lived signed upload/read URLs.

## Upload flow

1. Mobile picks a photo/PDF.
2. API authenticates the user and verifies item ownership.
3. API creates an object key under `users/<userId>/items/<itemId>/<kind>/...`.
4. API returns a 15-minute signed PUT URL.
5. Mobile uploads directly to the bucket.
6. API stores only metadata and the asset ID in MySQL.
7. Snapshot requests receive a fresh 1-hour signed read URL.

## Security

- Storage credentials are server-only.
- Asset presigning requires an authenticated JEHAZI session.
- An asset can only be created for an item owned by the authenticated user.
- Asset IDs are scoped to the authenticated user for deletion.
- Password hashes and storage secrets are never returned to the client.

## Local-first fallback

If storage variables are absent, JEHAZI keeps attachments on the device exactly as before. The UI does not fail hard; it shows a local-save message.
