/** @type {const} */
const themeColors = {
  primary: { light: '#8B5E73', dark: '#D6AFC0' },
  secondary: { light: '#C49A55', dark: '#E2C27E' },
  background: { light: '#F7F0E6', dark: '#17131A' },
  surface: { light: '#FFFDF9', dark: '#211B23' },
  foreground: { light: '#34283A', dark: '#F8F1E8' },
  muted: { light: '#83777D', dark: '#BEB2B8' },
  border: { light: '#E7DCD0', dark: '#433741' },
  success: { light: '#607D68', dark: '#9CBD9F' },
  warning: { light: '#B7863F', dark: '#E0B86E' },
  error: { light: '#B96263', dark: '#E39A9A' },
  sage: { light: '#DDE4D8', dark: '#334038' },
  champagne: { light: '#F0E2C4', dark: '#4A3E2B' },
};

module.exports = { themeColors };
