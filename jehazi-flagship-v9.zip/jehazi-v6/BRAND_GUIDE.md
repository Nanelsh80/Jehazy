# JEHAZI Flagship Brand System

## Positioning
JEHAZI (جهازي) is a calm, intelligent preparation companion for brides. The brand should feel premium, reassuring and organized — never childish or overly bridal.

## Core palette
- Deep Plum: #34283A — primary brand anchor
- Soft Plum: #8B5E73 — interaction/accent
- Champagne Gold: #D6B06A — premium highlight
- Ivory: #F7F0E6 — app canvas/background
- Cream: #FFFDF9 — cards/surfaces
- Sage: #DDE4D8 — calm success/supportive states

## Visual language
- Rounded, editorial cards with generous spacing.
- Quiet luxury rather than glitter or heavy wedding motifs.
- Gold is an accent, never a large background.
- Use RTL-first hierarchy and short Arabic labels.
- Iconography should be simple, geometric and consistent.

## Product voice
Warm, concise, reassuring and action-oriented. The app should feel like a trusted personal organizer.

## Signature line
تجهيزك… بهدوء، خطوة بخطوة
