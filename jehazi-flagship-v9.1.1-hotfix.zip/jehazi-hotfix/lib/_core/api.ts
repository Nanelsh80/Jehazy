import { Platform } from "react-native";
import { getApiBaseUrl } from "@/constants/auth";
import * as Auth from "./auth";

const authExpiryListeners = new Set<() => void>();
export function onAuthExpired(listener: () => void) {
  authExpiryListeners.add(listener);
  return () => authExpiryListeners.delete(listener);
}
function notifyAuthExpired() {
  authExpiryListeners.forEach((listener) => listener());
}

type ApiResponse<T> = {
  data?: T;
  error?: string;
};

export async function apiCall<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...((options.headers as Record<string, string>) || {}),
  };

  // Determine the auth method:
  // - Native platform: use stored session token as Bearer auth
  // - Web (including iframe): use cookie-based auth (browser handles automatically)
  //   Cookie is set on backend domain via POST /api/auth/session after receiving token via postMessage
  if (Platform.OS !== "web") {
    const sessionToken = await Auth.getSessionToken();
    console.log("[API] apiCall:", {
      endpoint,
      hasToken: !!sessionToken,
      method: options.method || "GET",
    });
    if (sessionToken) {
      headers["Authorization"] = `Bearer ${sessionToken}`;
      console.log("[API] Authorization header added");
    }
  } else {
    console.log("[API] apiCall:", { endpoint, platform: "web", method: options.method || "GET" });
  }

  const baseUrl = getApiBaseUrl();
  // Native builds may intentionally run without a backend (offline/local mode).
  if (!baseUrl && Platform.OS !== "web") {
    throw new Error("OFFLINE_API_UNAVAILABLE");
  }
  // Ensure no double slashes between baseUrl and endpoint
  const cleanBaseUrl = baseUrl.endsWith("/") ? baseUrl.slice(0, -1) : baseUrl;
  const cleanEndpoint = endpoint.startsWith("/") ? endpoint : `/${endpoint}`;
  const url = baseUrl ? `${cleanBaseUrl}${cleanEndpoint}` : endpoint;
  console.log("[API] Full URL:", url);

  try {
    console.log("[API] Making request...");
    const response = await fetch(url, {
      ...options,
      headers,
      credentials: "include",
    });

    console.log("[API] Response status:", response.status, response.statusText);
    const responseHeaders = Object.fromEntries(response.headers.entries());
    console.log("[API] Response headers:", responseHeaders);

    // Check if Set-Cookie header is present (cookies are automatically handled in React Native)
    const setCookie = response.headers.get("Set-Cookie");
    if (setCookie) {
      console.log("[API] Set-Cookie header received:", setCookie);
    }

    if (response.status === 401) {
      notifyAuthExpired();
    }

    if (!response.ok) {
      const errorText = await response.text();
      console.error("[API] Error response:", errorText);
      let errorMessage = errorText;
      try {
        const errorJson = JSON.parse(errorText);
        errorMessage = errorJson.error || errorJson.message || errorText;
      } catch {
        // Not JSON, use text as is
      }
      throw new Error(errorMessage || `API call failed: ${response.statusText}`);
    }

    const contentType = response.headers.get("content-type");
    if (contentType && contentType.includes("application/json")) {
      const data = await response.json();
      console.log("[API] JSON response received");
      return data as T;
    }

    const text = await response.text();
    console.log("[API] Text response received");
    return (text ? JSON.parse(text) : {}) as T;
  } catch (error) {
    console.error("[API] Request failed:", error);
    if (error instanceof Error) {
      throw error;
    }
    throw new Error("Unknown error occurred");
  }
}

// OAuth callback handler - exchange code for session token
// Calls /api/oauth/mobile endpoint which returns JSON with app_session_id and user
// Logout
export async function logout(): Promise<void> {
  await apiCall<void>("/api/auth/logout", {
    method: "POST",
  });
}

// Get current authenticated user (web uses cookie-based auth)
export async function getMe(): Promise<{
  id: number;
  openId: string;
  name: string | null;
  email: string | null;
  loginMethod: string | null;
  lastSignedIn: string;
} | null> {
  try {
    const result = await apiCall<{ user: any }>("/api/auth/me");
    return result.user || null;
  } catch (error) {
    console.error("[API] getMe failed:", error);
    return null;
  }
}

// Establish session cookie on the backend (3000-xxx domain)
// Called after receiving token via postMessage to get a proper Set-Cookie from the backend
export async function establishSession(token: string): Promise<boolean> {
  try {
    console.log("[API] establishSession: setting cookie on backend...");
    const baseUrl = getApiBaseUrl();
    const url = `${baseUrl}/api/auth/session`;

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      credentials: "include", // Important: allows Set-Cookie to be stored
    });

    if (!response.ok) {
      console.error("[API] establishSession failed:", response.status);
      return false;
    }

    console.log("[API] establishSession: cookie set successfully");
    return true;
  } catch (error) {
    console.error("[API] establishSession error:", error);
    return false;
  }
}

export type JeHaziSnapshot = {
  profile: { name: string; weddingDate: string; budget: number };
  items: any[];
};

export async function getJeHaziSnapshot(): Promise<JeHaziSnapshot | null> {
  return apiCall<JeHaziSnapshot | null>("/api/jehazi/snapshot");
}

export async function saveJeHaziSnapshot(snapshot: JeHaziSnapshot): Promise<JeHaziSnapshot> {
  return apiCall<JeHaziSnapshot>("/api/jehazi/snapshot", {
    method: "PUT",
    body: JSON.stringify(snapshot),
  });
}

export type JeHaziAssetKind = "photo" | "receipt" | "warranty";

export async function uploadLocalAsset(input: {
  itemId: string;
  kind: JeHaziAssetKind;
  uri: string;
  fileName: string;
  contentType?: string;
}): Promise<{ assetId: string; readUrl: string | null; fileName: string }> {
  const response = await apiCall<{ id: string; uploadUrl: string; readUrl: string | null; fileName: string }>("/api/jehazi/assets/presign", {
    method: "POST",
    body: JSON.stringify({ itemId: input.itemId, kind: input.kind, fileName: input.fileName, contentType: input.contentType || "application/octet-stream" }),
  });
  const localResponse = await fetch(input.uri);
  const blob = await localResponse.blob();
  const upload = await fetch(response.uploadUrl, { method: "PUT", headers: { "Content-Type": input.contentType || blob.type || "application/octet-stream" }, body: blob });
  if (!upload.ok) throw new Error(`Cloud upload failed (${upload.status})`);
  return { assetId: response.id, readUrl: response.readUrl, fileName: response.fileName };
}

export async function deleteCloudAsset(assetId: string): Promise<void> {
  await apiCall(`/api/jehazi/assets/${encodeURIComponent(assetId)}`, { method: "DELETE" });
}
