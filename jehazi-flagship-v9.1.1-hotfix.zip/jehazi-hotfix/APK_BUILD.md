# JEHAZI direct APK

JEHAZI is configured for a directly installable Android APK; Google Play is not required.

## Build profile

Use the `preview` or `production-apk` EAS profile. Both produce an `.apk`, not an `.aab`.

## Important

The app supports **local/offline mode**. The user can choose `استخدمي جهازي بدون حساب` and use the inventory, budget, onboarding, warranty center, shopping and command center without a backend.

Cloud authentication/sync/storage remain optional and require `EXPO_PUBLIC_API_BASE_URL` plus the backend/storage environment.
