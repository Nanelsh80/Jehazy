# JEHAZI Local Device Mode

JEHAZI can run fully offline without an account or backend.

- Tap **استخدمي جهازي بدون حساب** on the auth screen.
- The app stores inventory, bride profile, onboarding state, attachments and local reminders on the device.
- The inventory layer detects the `local-device-session` marker and skips all cloud/auth API calls.
- Cloud sync is optional and only activates after a real account session is present.
- Do not delete app storage if you want to preserve local data.
