import { useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import * as Api from "@/lib/_core/api";
import * as Auth from "@/lib/_core/auth";
import { useInventory } from "@/lib/inventory-context";

export default function AuthScreen() {
  const router = useRouter();
  const { onboardingComplete } = useInventory();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [guestBusy, setGuestBusy] = useState(false);

  async function continueOffline() {
    if (guestBusy) return;
    setGuestBusy(true);
    try {
      const guest = {
        id: 0,
        openId: "local-device",
        name: name.trim() || "عروسة جهازي",
        email: null,
        loginMethod: "local",
        lastSignedIn: new Date(),
      };
      await Auth.setUserInfo(guest);
      await Auth.setSessionToken("local-device-session");
      router.replace(onboardingComplete ? "/(tabs)" : "/onboarding?step=profile");
    } finally {
      setGuestBusy(false);
    }
  }

  async function submit() {
    if (busy) return;
    setBusy(true);
    try {
      const result = mode === "login"
        ? await Api.loginAccount(email, password)
        : await Api.registerAccount(name, email, password);
      if (result.sessionToken) await Auth.setSessionToken(result.sessionToken);
      await Auth.setUserInfo({ ...result.user, lastSignedIn: new Date(result.user.lastSignedIn) });
      router.replace(onboardingComplete ? "/(tabs)" : "/onboarding?step=profile");
    } catch (error) {
      Alert.alert("تعذر المتابعة", error instanceof Error ? error.message : "حاولي مرة أخرى بعد قليل.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <View style={styles.brandMark}><Text style={styles.brandJ}>J</Text><View style={styles.goldDot} /></View>
          <Text style={styles.kicker}>JEHAZI • جهازي</Text>
          <Text style={styles.title}>{mode === "login" ? "أهلاً بعودتكِ" : "ابدئي رحلتكِ"}</Text>
          <Text style={styles.subtitle}>حسابك يحفظ تجهيزاتك وميزانيتك ويخلّي جهازي معكِ أينما كنتِ.</Text>

          {mode === "register" && <Field label="اسمك" value={name} onChangeText={setName} placeholder="مثال: سارة" />}
          <Field label="البريد الإلكتروني" value={email} onChangeText={setEmail} placeholder="name@example.com" keyboardType="email-address" autoCapitalize="none" />
          <Field label="كلمة المرور" value={password} onChangeText={setPassword} placeholder="8 أحرف على الأقل" secureTextEntry />

          <Pressable disabled={busy} onPress={submit} style={({ pressed }) => [styles.primary, (pressed || busy) && styles.pressed]}>
            <MaterialIcons name={mode === "login" ? "login" : "person-add"} size={20} color="#FFF9F0" />
            <Text style={styles.primaryText}>{busy ? "جاري التحضير…" : mode === "login" ? "تسجيل الدخول" : "إنشاء حساب"}</Text>
          </Pressable>

          <Pressable onPress={() => setMode(mode === "login" ? "register" : "login")} style={styles.switchButton}>
            <Text style={styles.switchText}>{mode === "login" ? "لسه معندكيش حساب؟ إنشاء حساب" : "عندي حساب بالفعل • تسجيل الدخول"}</Text>
          </Pressable>

          <Pressable disabled={busy || guestBusy} onPress={continueOffline} style={styles.offlineButton}>
            <MaterialIcons name="phone-android" size={18} color="#8B5E73" />
            <Text style={styles.offlineText}>{guestBusy ? "جاري فتح جهازي…" : "استخدمي جهازي بدون حساب"}</Text>
          </Pressable>

          <View style={styles.offlineNote}>
            <MaterialIcons name="cloud-off" size={16} color="#8B7A70" />
            <Text style={styles.offlineNoteText}>الوضع المحلي يحفظ بياناتك على الهاتف. يمكنك إضافة حساب ومزامنتها سحابيًا لاحقًا.</Text>
          </View>

          <View style={styles.security}><MaterialIcons name="lock-outline" size={17} color="#8B5E73" /><Text style={styles.securityText}>بيانات الحساب مشفرة أثناء النقل، والجلسة محفوظة بأمان على جهازك.</Text></View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

function Field({ label, value, onChangeText, placeholder, keyboardType, secureTextEntry, autoCapitalize }: any) {
  return <View style={styles.field}><Text style={styles.label}>{label}</Text><TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor="#B0A59D" keyboardType={keyboardType} secureTextEntry={secureTextEntry} autoCapitalize={autoCapitalize} style={styles.input} textAlign="right" /></View>;
}

const styles = StyleSheet.create({
  flex: { flex: 1 }, content: { flexGrow: 1, paddingTop: 55, paddingBottom: 35, writingDirection: "rtl" },
  brandMark: { width: 74, height: 74, borderRadius: 25, backgroundColor: "#34283A", alignSelf: "center", alignItems: "center", justifyContent: "center", marginBottom: 15 }, brandJ: { color: "#FFFDF9", fontSize: 37, fontWeight: "300", fontStyle: "italic" }, goldDot: { position: "absolute", width: 11, height: 11, borderRadius: 6, backgroundColor: "#D6B06A", bottom: 17, right: 17 },
  kicker: { color: "#8B5E73", fontSize: 12, fontWeight: "800", textAlign: "center" }, title: { color: "#34283A", fontSize: 30, fontWeight: "900", textAlign: "center", marginTop: 8 }, subtitle: { color: "#8B7A70", fontSize: 12, lineHeight: 20, textAlign: "center", marginTop: 8, marginBottom: 28, paddingHorizontal: 14 },
  field: { marginBottom: 15 }, label: { color: "#5E514A", fontSize: 12, fontWeight: "800", textAlign: "right", marginBottom: 7 }, input: { height: 52, backgroundColor: "#FFFDFC", borderWidth: 1, borderColor: "#E9DED4", borderRadius: 16, paddingHorizontal: 14, color: "#34283A", fontSize: 13 },
  primary: { height: 54, backgroundColor: "#8B5E73", borderRadius: 17, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 7, shadowColor: "#8B5E73", shadowOpacity: 0.2, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 3 }, primaryText: { color: "#FFF9F0", fontSize: 15, fontWeight: "900" }, switchButton: { paddingVertical: 18, alignItems: "center" }, switchText: { color: "#8B5E73", fontSize: 12, fontWeight: "800", textAlign: "center" }, security: { flexDirection: "row-reverse", alignItems: "center", gap: 7, backgroundColor: "#F4E9D8", borderRadius: 15, padding: 12, marginTop: 10 }, securityText: { flex: 1, color: "#7C6950", fontSize: 10, lineHeight: 16, textAlign: "right" }, pressed: { opacity: 0.65 },
});
