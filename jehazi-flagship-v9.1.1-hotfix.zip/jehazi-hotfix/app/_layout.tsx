import "../global.css";
import { Redirect, Stack, useSegments } from "expo-router";
import { useEffect, useState } from "react";
import { Pressable, Text, View } from "react-native";
import { StatusBar } from "expo-status-bar";
import { ThemeProvider } from "@/lib/theme-provider";
import { InventoryProvider, useInventory } from "@/lib/inventory-context";

export default function RootLayout() {
  return (
    <ThemeProvider>
      <InventoryProvider>
        <AppNavigator />
      </InventoryProvider>
    </ThemeProvider>
  );
}


function BootScreen({ slow }: { slow: boolean }) {
  return (
    <View style={{ flex: 1, backgroundColor: "#F7F0E6", alignItems: "center", justifyContent: "center", padding: 28 }}>
      <View style={{ width: 82, height: 82, borderRadius: 28, backgroundColor: "#34283A", alignItems: "center", justifyContent: "center", marginBottom: 18 }}>
        <Text style={{ color: "#FFFDF9", fontSize: 40, fontWeight: "300", fontStyle: "italic" }}>J</Text>
        <View style={{ position: "absolute", width: 11, height: 11, borderRadius: 6, backgroundColor: "#D6B06A", right: 18, bottom: 18 }} />
      </View>
      <Text style={{ color: "#34283A", fontSize: 22, fontWeight: "800", textAlign: "center" }}>جهازي</Text>
      <Text style={{ color: "#8B5E73", fontSize: 12, marginTop: 8, textAlign: "center" }}>{slow ? "بنجهّز مساحتك المحلية…" : "لحظة ونبدأ…"}</Text>
    </View>
  );
}

export function ErrorBoundary({ error, retry }: { error: Error & { digest?: string }; retry: () => void }) {
  return (
    <View style={{ flex: 1, backgroundColor: "#F7F0E6", alignItems: "center", justifyContent: "center", padding: 28 }}>
      <Text style={{ color: "#34283A", fontSize: 24, fontWeight: "800", textAlign: "center" }}>جهازي يحتاج إعادة فتح</Text>
      <Text style={{ color: "#8B7A70", fontSize: 13, lineHeight: 21, textAlign: "center", marginTop: 10 }}>حدث خطأ أثناء تشغيل الواجهة. اضغطي المحاولة مرة أخرى.</Text>
      <Pressable onPress={retry} style={{ marginTop: 22, backgroundColor: "#8B5E73", paddingHorizontal: 24, paddingVertical: 13, borderRadius: 15 }}>
        <Text style={{ color: "#FFF9F0", fontWeight: "800" }}>إعادة المحاولة</Text>
      </Pressable>
      {__DEV__ ? <Text selectable style={{ color: "#9B6B6B", fontSize: 9, marginTop: 18, textAlign: "center" }}>{error?.message}</Text> : null}
    </View>
  );
}

function AppNavigator() {
  const { hydrated, onboardingComplete } = useInventory();
  const segments = useSegments();
  const onOnboarding = segments[0] === "onboarding";
  const onAuth = segments[0] === "auth";
  const [bootSlow, setBootSlow] = useState(false);

  useEffect(() => {
    if (hydrated) return;
    const timer = setTimeout(() => setBootSlow(true), 2500);
    return () => clearTimeout(timer);
  }, [hydrated]);

  // JEHAZI is local-first: the app must never block startup on account/cloud state.
  if (!hydrated) return <BootScreen slow={bootSlow} />;
  if (onAuth) return <Redirect href={onboardingComplete ? "/(tabs)" : "/onboarding?step=profile"} />;
  if (!onboardingComplete && !onOnboarding) return <Redirect href="/onboarding?step=profile" />;
  if (onboardingComplete && onOnboarding) return <Redirect href="/(tabs)" />;

  return <>
    <StatusBar style="dark" />
    <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: "#F7F0E6" } }}>
      <Stack.Screen name="auth" options={{ gestureEnabled: false }} />
      <Stack.Screen name="onboarding" options={{ gestureEnabled: false }} />
    </Stack>
  </>;
}
